package com.app.projeto.app2_projeto_integrador_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
