import 'package:flutter/cupertino.dart';
/*********NÃO UTILIZADO***********/

class ListaSelecionarProfissional extends StatefulWidget {
  const ListaSelecionarProfissional({super.key});

  @override
  State<ListaSelecionarProfissional> createState() => _ListaSelecionarProfissionalState();
}

class _ListaSelecionarProfissionalState extends State<ListaSelecionarProfissional> {
  @override
  Widget build(BuildContext context) {
    return
      Expanded(child:
        Container(
          height: 600,
          width: 400,
          /*child: CardHorarioRelatorio(
            resultados: relatorio,
          )*/
        )
      );
  }
}
