class Usuario{

  Usuario(String nome, String email){
    _nomeProfissional = nome;
    _email = email;
  }

  String _nomeProfissional = "";
  String _email = "";


  String get nomeProfissional => _nomeProfissional;
  String get email => _email;

}