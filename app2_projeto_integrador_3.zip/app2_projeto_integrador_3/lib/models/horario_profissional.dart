class HorarioProfissional{

  HorarioProfissional(String nome, String horarioInicio, String horaFim, String dia, String mes, String ano, bool marcado){
    _nomeProfissional = nome;
    _horaInicio = horarioInicio;
    _horaFim = horaFim;
    _marcado = marcado;
    _dia = dia;
    _mes = mes;
    _ano = ano;
  }

  String _nomeProfissional = "";
  String _horaInicio = "";
  String _horaFim = "";
  String _dia = "";
  String _mes = "";
  String _ano = "";
  bool _marcado = false;

  String get nomeProfissional => _nomeProfissional;
  String get horaInicio => _horaInicio;
  String get horaFim => _horaFim;
  String get dia => _dia;
  String get mes => _mes;
  String get ano => _ano;
  bool get marcado => _marcado;

}