import 'package:app2_projeto_integrador_3/cardHorarioRelatorio.dart';
import 'package:app2_projeto_integrador_3/models/usuarios.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Relatorio extends StatefulWidget{
  const Relatorio({super.key});



  @override
  State<Relatorio> createState() => _Relatorio();
}

class _Relatorio extends State<Relatorio> {
  final FirebaseFirestore _database = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Escolha um funcionário"),
          backgroundColor: Colors.blue[900],
          foregroundColor: CupertinoColors.white,
        ),
        body: StreamBuilder<QuerySnapshot>(
        stream : _database.collection("email_usuario").orderBy("nome", descending: false).snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot){
          if(!snapshot.hasData){
            return Center(child: CircularProgressIndicator(),);
          }
          if(snapshot.hasError){
            return Text("Não foi possível conectar com o Banco de Dados");
          }
          if(snapshot.connectionState == ConnectionState.waiting){
            return Center(child: CircularProgressIndicator(),);
          }

          final usuarios = snapshot.requireData;
          final List<Usuario> usuariosLista = List.empty(growable: true);
          final userTodos = Usuario("TODOS", "");
          usuariosLista.add(userTodos);


          for(var us in usuarios.docs){
            var temp = Usuario("${us["nome"]} ${us["sobrenome"]}", us["usuario"]);
            usuariosLista.add(temp);
          }

          return ListView.builder(
            itemCount: usuariosLista.length,
            padding: EdgeInsetsDirectional.all(20),
            itemBuilder: (context, index){
              var usuario = usuariosLista[index];
              print("Nome Usuario : ${usuario.nomeProfissional}");
              return ListTile(
                title: Text(usuario.nomeProfissional, textAlign: TextAlign.center, style: TextStyle(color: CupertinoColors.white),),
                onTap: (){
                  Navigator.push(context,
                      MaterialPageRoute(
                      builder: (context) =>
                      CardHorarioRelatorio(usuario: usuario, usuarios: usuariosLista,),
                  ),
                  );
                },
                tileColor: Colors.deepOrangeAccent,
                shape: StadiumBorder(side: BorderSide(width: 1, style: BorderStyle.solid, color: Colors.white)),
              );
            },
          );

      }
    ));
  }
}