import 'package:app2_projeto_integrador_3/cardHorarioRelatorio.dart';
import 'package:app2_projeto_integrador_3/models/horario_profissional.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class Relatorio extends StatefulWidget{
  const Relatorio({super.key});

  @override
  State<Relatorio> createState() => _Relatorio();
}

class _Relatorio extends State<Relatorio> {
  var _profissionalSelecionado = "TODOS";
  List<String> _profissionaisDisponiveis = ["TODOS", "aa"];
  HorarioProfissional prof = HorarioProfissional("Pedro", "10:30", "11:30", "01", "12", "2024", true);
  ValueNotifier<List<HorarioProfissional>> profs = ValueNotifier<List<HorarioProfissional>>(List.empty(growable: true));

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery
        .of(context)
        .size
        .height;
    double screenWidth = MediaQuery
        .of(context)
        .size
        .width;

    return Scaffold(
        backgroundColor: Colors.blue[900],
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            /*Text("Relatório de Ponto",
              style: TextStyle(fontSize: 30, color: Colors.white,),
              textAlign: TextAlign.center,),*/


            Padding(padding: EdgeInsetsDirectional.only(top: 35)),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  alignment: AlignmentDirectional.center,
                  width: 200,
                  decoration: BoxDecoration(color: CupertinoColors.white, borderRadius: BorderRadius.all(Radius.circular(10))),
                  child: DropdownButton(
                    underline: Container(),
                    isExpanded: true,
                    dropdownColor: Colors.deepOrangeAccent,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    iconEnabledColor: Colors.black,
                    items: _profissionaisDisponiveis.map((String item) {
                      return DropdownMenuItem(
                        alignment: Alignment.center,
                        child: Text(item),
                        value: item,
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      setState(() {
                        _profissionalSelecionado = newValue!;
                        print(_profissionalSelecionado);
                      });
                    },
                    value: _profissionalSelecionado,
                    disabledHint: Text("Não há profissionais"),
                  ),
                ),
                SizedBox(
                  width: 100,
                  height: 50,
                  child: FloatingActionButton(
                    backgroundColor: Colors.deepOrangeAccent,
                    onPressed: (){
                      profs.value.add(prof);
                      profs.notifyListeners();
                      print(profs);
                  },
                    child: Text("Gerar", style: TextStyle(fontSize: 18),),
                  ),
                ),


              ],),
          Expanded(child:
            Container(
              height: 600,
              width: 400,
              child: CardHorarioRelatorio(
                horario: profs,
              )
            )
          ),

            ],
        )
    );
  }
}