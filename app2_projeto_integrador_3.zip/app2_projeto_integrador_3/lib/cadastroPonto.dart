import 'dart:ffi';

import 'package:app2_projeto_integrador_3/models/usuarios.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'models/horario_profissional.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _Home();
}

class _Home extends State<Home> {
  FirebaseFirestore db = FirebaseFirestore.instance;
  List<Usuario> _profissionaisDisponiveis = List.empty(growable: true);
  Usuario? _profissionalSelecionado;

  TextEditingController controllerDia = TextEditingController();
  TextEditingController controllerMes = TextEditingController();
  TextEditingController controllerAno = TextEditingController();

  String? diaSelecionado;
  String? mesSelecionado;
  String? anoSelecionado;

  bool podeVerPonto = false;

  var _horarios = [
    "08:00",
    "08:30",
    "09:00",
    "09:30",
    "10:00",
    "10:30",
    "11:00",
    "11:30",
    "12:00",
    "12:30",
    "13:00",
    "13:30",
    "14:00",
    "14:30",
    "15:00",
    "15:30",
    "16:00",
    "16:30",
    "17:00",
    "17:30",
    "18:00",
    "18:30",
    "19:00",
    "19:30",
    "20:00",
    "20:30",
    "21:00",
    "21:30",
    "22:00",
    "22:30"
  ];

  Future<bool> validarPonto() async{
    String? msgErro;

    var dataInicio =  DateTime.parse(
        "${DateTime.now().year}"
            "-${DateTime.now().month.toString().length == 1 ? "0${DateTime.now().month}" : DateTime.now().month}"
            "-${DateTime.now().day.toString().length == 1 ? "0${DateTime.now().day}" : DateTime.now().day} "
            "$_horarioInicioSelecionado:00.000");

    var dataFim = DateTime.parse("${DateTime.now().year}"
        "-${DateTime.now().month.toString().length == 1 ? "0${DateTime.now().month}" : DateTime.now().month}"
        "-${DateTime.now().day.toString().length == 1 ? "0${DateTime.now().day}" : DateTime.now().day} "
        "$_horarioFimSelecionado:00.000");

    print(dataInicio);
    print(dataFim);

    if(dataInicio.isAfter(dataFim)) {
      msgErro = "Horário inicio deve ser menor que horário fim!";
    }else if(_horarioInicioSelecionado == _horarioFimSelecionado){
      msgErro = "Horário inicio deve ser diferente do horário fim!";
    }else if(int.parse(diaSelecionado!) > 31 || int.parse(diaSelecionado!) < 1){
      msgErro = "Informe um dia válido! (1 a 31)";
    }else if(int.parse(mesSelecionado!) > 12 || int.parse(mesSelecionado!) < 1){
      msgErro = "Informe um mês válido! (1 a 12)";
    }else if(int.parse(anoSelecionado!) < 1970){
      msgErro = "Ano inválido!";
    }else{
      final result = await db.collection("horario_profissional")
          .where("profissional", isEqualTo: _profissionalSelecionado!.email)
          .where("dia", isEqualTo: int.parse(diaSelecionado!).toString())
          .where("mes", isEqualTo: int.parse(mesSelecionado!).toString())
          .where("ano", isEqualTo: int.parse(anoSelecionado!).toString())
          .get();

      if (result.docs.isNotEmpty) {
        for (QueryDocumentSnapshot doc in result.docs) {
          var data = doc.data() as Map<String, dynamic>;
          DateTime horaInicioDoc = DateTime.parse("${DateTime.now().year}-${DateTime.now().month.toString().length == 1 ? "0${DateTime.now().month}" : DateTime.now().month}-${DateTime.now().day.toString().length == 1 ? "0${DateTime.now().day}" : DateTime.now().day} ${data["horario_inicio"]}:00.000");
          DateTime horaFimDoc = DateTime.parse("${DateTime.now().year}-${DateTime.now().month.toString().length == 1 ? "0${DateTime.now().month}" : DateTime.now().month}-${DateTime.now().day.toString().length == 1 ? "0${DateTime.now().day}" : DateTime.now().day} ${data["horario_fim"]}:00.000");
          DateTime horaInicioSelecionado = DateTime.parse("${DateTime.now().year}-${DateTime.now().month.toString().length == 1 ? "0${DateTime.now().month}" : DateTime.now().month}-${DateTime.now().day.toString().length == 1 ? "0${DateTime.now().day}" : DateTime.now().day} $_horarioInicioSelecionado:00.000");
          DateTime horaFimSelecionado = DateTime.parse("${DateTime.now().year}-${DateTime.now().month.toString().length == 1 ? "0${DateTime.now().month}" : DateTime.now().month}-${DateTime.now().day.toString().length == 1 ? "0${DateTime.now().day}" : DateTime.now().day} $_horarioFimSelecionado:00.000");
          
          if(_horarioInicioSelecionado == data["horario_inicio"]
              || _horarioFimSelecionado == data["horario_fim"]
              || (horaInicioSelecionado.isAfter(horaInicioDoc) && horaInicioSelecionado.isBefore(horaFimDoc))
              || (horaInicioSelecionado.isBefore(horaInicioDoc) && horaFimSelecionado.isAfter(horaFimDoc)
                  || horaFimSelecionado.isAfter(horaInicioDoc) && horaFimSelecionado.isBefore(horaFimDoc))
          ){
            print("Entrou NO IF");
            msgErro = "Horário indísponível, aula marcada para ${data["horario_inicio"]} - ${data["horario_fim"]}";
          }
        }

      }
    }

    if(msgErro != null){
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(msgErro),
      ));
      return false;
    }

    return true;
  }

  Future<void> salvarNovoPonto() async {
    setState(() {
      podeVerPonto = false;
    });

    if(await validarPonto()){
      //Retira os zeros a esquerda caso exista
      var mes = int.parse(mesSelecionado!);
      var dia = int.parse(diaSelecionado!);
      var ano = int.parse(anoSelecionado!);


      db.collection("horario_profissional").add(
          {"profissional": _profissionalSelecionado!.email,
            "ano" : ano.toString(),
            "dia": dia.toString(),
            "mes": mes.toString(),
            "horario_fim": _horarioFimSelecionado,
            "horario_inicio" : _horarioInicioSelecionado,
            "compareceu": _pontoVerificado,
          }
      );

      setState(() {
        controllerDia.clear();
        controllerMes.clear();
        controllerAno.clear();
        diaSelecionado = "";
        mesSelecionado = "";
        anoSelecionado = "";
        podeVerPonto = false;
        _horarioFimSelecionado = "08:30";
        _horarioInicioSelecionado = "08:00";
      });
    }else{
      setState(() {
        podeVerPonto = true;
      });
    }
  }
  
  Future<void> buscarProfissionais() async {
    final dados =
        await FirebaseFirestore.instance.collection("email_usuario").get();
    if (dados.docs.isNotEmpty) {
      for (QueryDocumentSnapshot doc in dados.docs) {
        var data = doc.data() as Map<String, dynamic>;

        setState(() {
          _profissionaisDisponiveis.add(Usuario("${data["nome"]} ${data["sobrenome"]}", data["usuario"]));
        });
      }
      _profissionalSelecionado = _profissionaisDisponiveis.first;
    }
  }

  void verificarTodosOsCamposPreenchidos() {
    if (_profissionalSelecionado != null &&
        (diaSelecionado != null && diaSelecionado != "") &&
        (mesSelecionado != null && mesSelecionado != "") &&
        (anoSelecionado != null && anoSelecionado!.length == 4 && anoSelecionado != "")) {
      setState(() {
        podeVerPonto = true;
      });
    } else {
      setState(() {
        podeVerPonto = false;
      });
      print("ainda não preenchido tudo");
    }
  }

  Future<void> mostrarPontosDoDia() async{
    var result =
    db.collection("horario_profissional")
        .where("profissional",
        isEqualTo: _profissionalSelecionado!.email)
        .where("dia", isEqualTo: int.parse(diaSelecionado!).toString())
        .where("mes", isEqualTo: int.parse(mesSelecionado!).toString()
        .toString(),)
        .where("ano", isEqualTo: anoSelecionado
        .toString(),)
        .snapshots();

    print("Profissional: $_profissionalSelecionado");
    print("Dia: $diaSelecionado");
    print("Mes: $mesSelecionado");
    print("Ano: $anoSelecionado");

    return await showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          insetPadding: EdgeInsets.all(10),
          backgroundColor: Colors.deepOrangeAccent,
          title: Text('Pontos do Dia Selecionado'),
          content: SizedBox(width: double.maxFinite, child: StreamBuilder<QuerySnapshot>(stream: result,
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshot) {
                if (!snapshot.hasData) {
                  return Padding(
                      padding: EdgeInsetsDirectional.only(top: 30),
                      child: Center(
                        child: CircularProgressIndicator(),)
                  );
                }
                if (snapshot.hasError) {
                  return Padding(
                      padding: EdgeInsetsDirectional.only(top: 30),
                      child: Text(
                        "Não foi possível carregar os dados",
                        style: TextStyle(
                            fontSize: 20, color: CupertinoColors
                            .black),
                        textAlign: TextAlign.center,)
                  );
                }
                if (snapshot.connectionState ==
                    ConnectionState.waiting) {
                  return Padding(
                      padding: EdgeInsetsDirectional.only(top: 30),
                      child:  Center(
                          child: CircularProgressIndicator(color: Colors.blue[900],)
                      )
                  );
                }

                final data = snapshot.requireData;
                if (data.docs.isEmpty) {
                  return Padding(
                    padding: EdgeInsetsDirectional.only(top: 30),
                    child: Text("Sem dados", style: TextStyle(
                        fontSize: 20, color: Colors.black),
                      textAlign: TextAlign.center,),
                  );
                }

                List<HorarioProfissional> pontoProfissional = List.empty(growable: true);
                for(var ponto in data.docs){
                  var temp;
                  temp = HorarioProfissional(_profissionalSelecionado!.nomeProfissional , ponto["horario_inicio"], ponto["horario_fim"], ponto["dia"], ponto["mes"], ponto["ano"], ponto["compareceu"]);


                  pontoProfissional.add(temp);
                }

                return  ListView.builder(

                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    itemCount: pontoProfissional.length,
                    itemBuilder: (BuildContext context, int index) {
                      var pontos = pontoProfissional[index];
                      var docBanco = data.docs[index];
                      return ListTile(
                          subtitle: Container( width: double.maxFinite, child: Card(
                            color: pontos.marcado
                                ? Colors.green
                                : Colors.red,
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment
                                    .start,
                                children: [
                                  Padding(padding: EdgeInsetsDirectional.only(top: 10)),
                                  Row(
                                      mainAxisAlignment: MainAxisAlignment
                                          .spaceAround,
                                      children: [

                                        Text(pontos.nomeProfissional,
                                          style: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight
                                                  .bold,
                                              color: CupertinoColors.white),),
                                        Icon(pontos.marcado ? Icons.thumb_up_alt_sharp : Icons.thumb_down_alt_sharp, color: CupertinoColors.white, size: 15,),
                                      ]
                                  ),
                                  Divider(color: CupertinoColors.white, height: 10, endIndent: 30, indent: 30, thickness: 2,),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      /*Padding(
                                          padding: EdgeInsetsDirectional
                                              .only(
                                              start: 50)),*/
                                      Text("Dia: ", style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight
                                              .bold,
                                          color: CupertinoColors.white)),
                                      Text(pontos.dia,
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: CupertinoColors.white)),
                                      /*Padding(
                                          padding: EdgeInsetsDirectional
                                              .only(
                                              start: 20)),*/
                                      Text("Mês: ", style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight
                                              .bold,
                                          color: CupertinoColors.white)),
                                      Text(pontos.mes,
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: CupertinoColors.white)),
                                      /*Padding(
                                          padding: EdgeInsetsDirectional
                                              .only(
                                              start: 30)),*/
                                      Text("Ano: ", style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight
                                              .bold,
                                          color: CupertinoColors.white)),
                                      Text(pontos.ano,
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: CupertinoColors.white)),
                                    ],
                                  ),

                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      /*Padding(
                                          padding: EdgeInsetsDirectional
                                              .only(
                                              start: 15)),*/
                                      Text("Horario Inicio:",
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight
                                                  .bold,
                                              color: CupertinoColors.white)),
                                      Text(pontos.horaInicio,
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: CupertinoColors.white)),
                                     /* Padding(
                                          padding: EdgeInsetsDirectional
                                              .only(
                                              start: 15)),*/
                                      Text("Horario Fim: ",
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight
                                                  .bold,
                                              color: CupertinoColors.white)),
                                      Text(pontos.horaFim, style: TextStyle(color: CupertinoColors.white, fontSize: 12),),

                                    ],
                                  ),
                                  Padding(padding: EdgeInsetsDirectional.only(bottom: 10)),

                                  /*Row(
                                              children: [
                                                Padding(
                                                    padding: EdgeInsetsDirectional
                                                        .only(
                                                        start: 10)),
                                                Text(
                                                  "Marcado: ", style: TextStyle(
                                                    fontWeight: FontWeight
                                                        .bold,
                                                    color: CupertinoColors.white),),
                                                Icon(pontos.marcado
                                                    ? Icons
                                                    .thumb_up_alt_sharp
                                                    : Icons
                                                    .thumb_down_alt_sharp,
                                                  size: 20, color: CupertinoColors.white,),
                                              ],
                                            )*/
                                ]),
                          )
                      ));
                    });
              }
          )
          ),
        );
      },
    );

  }

  @override
  void initState() {
    super.initState();
    setState(() {
      _horarioInicioSelecionado = "08:00";
      _horarioFimSelecionado = "08:30";
    });
    buscarProfissionais();
  }

  @override
  void dispose() {
   super.dispose();
  }

  String _horarioInicioSelecionado = "";
  String _horarioFimSelecionado = "";
  bool _pontoVerificado = false;

  @override
  Widget build(BuildContext context) {
    /* double screenHeight = MediaQuery
        .of(context)
        .size
        .height;*/
    double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
        appBar: AppBar(
          title: Text("Cadastro de Ponto"),
          backgroundColor: Colors.blue[900],
          foregroundColor: CupertinoColors.white,
        ),
        backgroundColor: Colors.white,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Column(children: [
              Text(
                "Selecione o Funcionário",
                style: TextStyle(color: Colors.black, fontSize: 16),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                Container(
                  height: 50,
                  width: 250,
                  decoration: BoxDecoration(
                      color: Colors.deepOrangeAccent,
                      borderRadius: BorderRadius.circular(10)),
                  child: DropdownButton(
                    underline: Container(),
                    isExpanded: true,
                    alignment: Alignment.center,
                    dropdownColor: Colors.deepOrangeAccent,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    iconEnabledColor: Colors.white,
                    items: _profissionaisDisponiveis.map((Usuario item) {
                      return DropdownMenuItem(
                        enabled: _profissionaisDisponiveis.isNotEmpty,
                        alignment: Alignment.center,
                        child: Text(
                          item.nomeProfissional,
                          style: TextStyle(
                              fontSize: 16, color: CupertinoColors.white),
                        ),
                        value: item,
                      );
                    }).toList(),
                    onChanged: (Usuario? newValue) {
                      setState(() {
                        _profissionalSelecionado = newValue!;
                        print(_profissionalSelecionado);
                      });
                    },
                    value: _profissionalSelecionado,
                    disabledHint: Text(
                      "Não há profissionais",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: CupertinoColors.white),
                    ),
                  ),
                ),
              FloatingActionButton(onPressed: podeVerPonto ? ()=> mostrarPontosDoDia() : null,
                child: Icon(Icons.remove_red_eye_outlined, color: Colors.black,),
                backgroundColor: podeVerPonto ? Colors.green : Colors.grey.withOpacity(.5),)
              ]),
            ]),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text(
                  "Compareceu?",
                  style: TextStyle(color: Colors.black, fontSize: 20),
                ),
                GestureDetector(
                  onTap: () {
                    setState(() => _pontoVerificado = !_pontoVerificado);
                    print(_pontoVerificado);
                  },
                  child: AnimatedContainer(
                      height: 23,
                      width: 23,
                      duration: const Duration(milliseconds: 500),
                      curve: Curves.easeIn,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(1.0),
                          border: Border.all(color: Colors.black, width: 1.5)),
                      child: _pontoVerificado
                          ? Image.asset(
                              "assets/check.png",
                              color: Colors.green,
                            )
                          : Image.asset(
                              "assets/close.png",
                              color: Colors.red,
                            )),
                ),
                /*Checkbox(
                  side: BorderSide(color: Colors.black),
                  activeColor: Colors.deepOrangeAccent,
                  checkColor: Colors.black,
                  value: _pontoVerificado,
                  onChanged: (bool? value) {
                    setState(() {
                      _pontoVerificado = value ?? false;
                      print(_pontoVerificado);
                    });
                  },
                ),*/
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: TextFormField(
                    controller: controllerDia,
                    textAlign: TextAlign.center,
                    inputFormatters: [new LengthLimitingTextInputFormatter(2), new FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                    onChanged: (string) {diaSelecionado = string; verificarTodosOsCamposPreenchidos();},
                    keyboardType:
                        TextInputType.numberWithOptions(decimal: true, signed: false),
                    decoration: InputDecoration(
                      labelText: "Dia",
                      labelStyle: TextStyle(color: Colors.black, fontSize: 16),
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.deepOrangeAccent,
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(10)),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepOrangeAccent),
                      ),
                    ),
                    style: TextStyle(color: Colors.black),
                  ),
                ),
                Padding(padding: EdgeInsetsDirectional.only(start: 10)),
                Container(
                  width: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: TextFormField(
                    controller: controllerMes,
                    textAlign: TextAlign.center,
                    inputFormatters: [new LengthLimitingTextInputFormatter(2), new FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                    onChanged: (string) {mesSelecionado = string; verificarTodosOsCamposPreenchidos();},
                    keyboardType:
                        TextInputType.numberWithOptions(decimal: false),
                    decoration: InputDecoration(
                      labelText: "Mês",
                      labelStyle: TextStyle(color: Colors.black, fontSize: 16),
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Colors.deepOrangeAccent, width: 2),
                          borderRadius: BorderRadius.circular(10)),
                      focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Colors.deepOrangeAccent)),
                    ),
                    style: TextStyle(color: Colors.black),
                  ),
                ),
                Padding(padding: EdgeInsetsDirectional.only(start: 10)),
                Container(
                  width: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: TextFormField(
                    controller: controllerAno,
                    textAlign: TextAlign.center,
                    inputFormatters: [new LengthLimitingTextInputFormatter(4), new FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                    onChanged: (string) {anoSelecionado = string; verificarTodosOsCamposPreenchidos();},
                    keyboardType:
                        TextInputType.numberWithOptions(decimal: false),
                    decoration: InputDecoration(
                      labelText: "Ano",
                      labelStyle: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Colors.deepOrangeAccent, width: 2),
                          borderRadius: BorderRadius.circular(10)),
                      focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Colors.deepOrangeAccent)),
                    ),
                    style: TextStyle(color: Colors.black),
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(children: [
                  Text(
                    "Horário Inicio",
                    style: TextStyle(fontSize: 15, color: Colors.black),
                  ),
                  Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                            color: Colors.deepOrangeAccent, width: 2),
                        borderRadius: BorderRadius.circular(10)),
                    alignment: Alignment.center,
                    width: 130,
                    child: DropdownButton<String>(
                      dropdownColor: Colors.deepOrangeAccent,
                      iconEnabledColor: Colors.black,
                      underline: Container(),
                      alignment: Alignment.center,
                      style: TextStyle(color: Colors.black, fontSize: 18),
                      items: _horarios.map((String item) {
                        return DropdownMenuItem(
                          child: Text(item),
                          value: item,
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          _horarioInicioSelecionado = newValue!;
                          print(
                              "Horario inicio selecionado: $_horarioInicioSelecionado");
                        });
                      },
                      value: _horarioInicioSelecionado,
                    ),
                  )
                ]),
                Padding(
                    padding: EdgeInsetsDirectional.only(start: 20, end: 20)),
                Column(children: [
                  Text(
                    "Horário Fim",
                    style: TextStyle(fontSize: 15, color: Colors.black),
                  ),
                  Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                            color: Colors.deepOrangeAccent, width: 2),
                        borderRadius: BorderRadius.circular(10)),
                    alignment: Alignment.center,
                    width: 130,
                    child: DropdownButton<String>(
                      alignment: Alignment.center,
                      dropdownColor: Colors.deepOrangeAccent,
                      iconEnabledColor: Colors.black,
                      underline: Container(),
                      style: TextStyle(color: Colors.black, fontSize: 18),
                      items: _horarios.map((String item) {
                        return DropdownMenuItem(
                          child: Text(item),
                          value: item,
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          _horarioFimSelecionado = newValue!;
                          print(
                              "Horario fim selecionado: $_horarioFimSelecionado");
                        });
                      },
                      value: _horarioFimSelecionado,
                    ),
                  )
                ]),
              ],
            ),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              SizedBox(
                width: screenWidth * 0.6,
                child: FloatingActionButton(
                  onPressed: podeVerPonto ? salvarNovoPonto
                      : () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Preencha os campos!"),)),
                  backgroundColor: Colors.deepOrangeAccent[200],
                  tooltip: "Inserir ponto",
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        "assets/add.png",
                        width: 20,
                        height: 20,
                        color: Colors.white,
                      ),
                      Padding(padding: EdgeInsets.symmetric(horizontal: 5)),
                      Text(
                          style: TextStyle(fontSize: 16, color: Colors.white),
                          "Inserir"),
                    ],
                  ),
                ),
              ),
              /*Padding(padding: EdgeInsets.all(10.0)),
              SizedBox(
                width: screenWidth * 0.3,
                child: FloatingActionButton(
                  onPressed: null,
                  backgroundColor: Colors.deepOrangeAccent[200],
                  tooltip: "Deletar ponto",
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        "assets/minus.png",
                        width: 20,
                        height: 20,
                        color: Colors.white,
                      ),
                      Padding(padding: EdgeInsets.symmetric(horizontal: 5)),
                      Text(
                          style: TextStyle(fontSize: 16, color: Colors.white),
                          "Deletar"),
                    ],
                  ),
                ),
              ),*/
            ]),
          ],
        ));
  }
}
