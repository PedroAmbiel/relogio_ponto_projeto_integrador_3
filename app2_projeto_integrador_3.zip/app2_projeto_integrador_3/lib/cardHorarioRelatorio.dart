import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:mat_month_picker_dialog/mat_month_picker_dialog.dart';


import 'models/horario_profissional.dart';
import 'models/usuarios.dart';

enum Meses{
  Janeiro(mes: 1, nome: "Janeiro"),
  Fevereiro(mes: 2, nome: "Fevereiro"),
  Marco(mes: 3, nome: "Março"),
  Abril(mes: 4, nome: "Abril"),
  Maio(mes: 5, nome: "Maio"),
  Junho(mes: 6, nome: "Junho"),
  Julho(mes: 7, nome: "Julho"),
  Agosto(mes: 8, nome: "Agosto"),
  Setembro(mes: 9, nome: "Setembro"),
  Outubro(mes: 10, nome: "Outubro"),
  Novembro(mes: 11, nome: "Novembro"),
  Dezembro(mes: 12, nome: "Dezembro");



  final int mes;
  final String nome;
  const Meses({
    required this.mes,
    required this.nome,
  });
}

class CardHorarioRelatorio extends StatefulWidget {
  CardHorarioRelatorio({super.key,  required this.usuario, this.usuarios});
  final Usuario usuario;
  List<Usuario>? usuarios;
  @override
  State<CardHorarioRelatorio> createState() => _CardHorarioRelatorio();
}

class _CardHorarioRelatorio extends State<CardHorarioRelatorio> {
  FirebaseFirestore database = FirebaseFirestore.instance;

  var _mesSelecionado = DateTime.now().month.toString();
  var _anoSelecionado = DateTime.now().year.toString();
  var result;




  buscarDadosIniciais() async {
    result =
        database.collection("horario_profissional")
            .where("profissional",
            isEqualTo: widget.usuario.nomeProfissional == "TODOS" ? null : widget.usuario.email)
            .where("mes", isEqualTo: DateTime
            .now()
            .month
            .toString(),)
            .where("ano", isEqualTo: DateTime
            .now()
            .year
            .toString(),)
            .snapshots();
  }


  dialogData() async {
    var results = await showMonthPicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1970),
      lastDate: DateTime(3000),
    );

    if (results != null) {
      _mesSelecionado = results.month.toString();
      _anoSelecionado = results.year.toString();

      setState(() {
        result =
            database.collection("horario_profissional")
                .where("profissional",
                isEqualTo: widget.usuario.nomeProfissional == "TODOS" ? null : widget.usuario.email)
                .where("mes", isEqualTo: _mesSelecionado,)
                .where("ano", isEqualTo: _anoSelecionado,)
                .snapshots();
      });
    }

  }

  deletarPonto(String idPonto) async{
    database.collection("horario_profissional").doc(idPonto).delete();
    setState(() {
      if(widget.usuario.nomeProfissional != "TODOS"){
        result = database.collection("horario_profissional")
            .where("profissional",
            isEqualTo: widget.usuario.email)
            .where("mes", isEqualTo: _mesSelecionado,)
            .where("ano", isEqualTo: _anoSelecionado,)
            .snapshots();
      }else{
        result = database.collection("horario_profissional")
            .where("mes", isEqualTo: _mesSelecionado,)
            .where("ano", isEqualTo: _anoSelecionado,)
            .snapshots();
      }

    });

    Navigator.of(context).pop();
  }

  @override
  void initState() {
    super.initState();
      buscarDadosIniciais();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar( title: Text("Pontos", style: TextStyle(color: CupertinoColors.white),),
      foregroundColor: CupertinoColors.white,
      actions: [
        Padding(padding: EdgeInsetsDirectional.only(end: 20),
          child: SizedBox(
          width: 150,
          height: 30,
          child: FloatingActionButton(
            backgroundColor: Colors.deepOrangeAccent,
            onPressed: () {
              dialogData();
              /*relatorio.value = FirebaseFirestore.instance.collection("horario_profissional")
                          .where("profissional", isEqualTo: _profissionalSelecionado == "TODOS" ? null : _profissionalSelecionado)
                          .snapshots();
                        //relatorio.notifyListeners();
                        print(relatorio);*/
            },
            child: Text("Selecione Mês e Ano", style: TextStyle(fontSize: 13, color: CupertinoColors.white),),
          ),
        )
    ),
      ],
      backgroundColor: Colors.blue[900],
      ),

        backgroundColor: Colors.white,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            /*Text("Relatório de Ponto",
                style: TextStyle(fontSize: 30, color: Colors.white,),
                textAlign: TextAlign.center,),*/

            Padding(padding: EdgeInsetsDirectional.only(top: 10)),


            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text("Mês Selecionado: ${Meses.values[int.parse(_mesSelecionado)-1].nome}"),
                Text("Ano Selecionado: ${_anoSelecionado}"),
              ],),
            Expanded(
                child: Container(
                    child: StreamBuilder<QuerySnapshot>(stream: result,
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (!snapshot.hasData) {
                            return Padding(
                                padding: EdgeInsetsDirectional.only(top: 30),
                                child: Center(
                                  child: CircularProgressIndicator(),)
                            );
                          }
                          if (snapshot.hasError) {
                            return Padding(
                                padding: EdgeInsetsDirectional.only(top: 30),
                                child: Text(
                                  "Não foi possível carregar os dados",
                                  style: TextStyle(
                                      fontSize: 20, color: CupertinoColors
                                      .black),
                                  textAlign: TextAlign.center,)
                            );
                          }
                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return Padding(
                                padding: EdgeInsetsDirectional.only(top: 30),
                                child:  Center(
                                    child: CircularProgressIndicator(color: Colors.blue[900],)
                                )
                            );
                          }

                          final data = snapshot.requireData;
                          if (data.docs.isEmpty) {
                            return Padding(
                              padding: EdgeInsetsDirectional.only(top: 30),
                              child: Text("Sem dados", style: TextStyle(
                                  fontSize: 20, color: Colors.black),
                                textAlign: TextAlign.center,),
                            );
                          }

                          List<HorarioProfissional> pontoProfissional = List.empty(growable: true);
                          for(var ponto in data.docs){
                            var temp;
                            if(widget.usuario.nomeProfissional == "TODOS"){
                              for(var usuario in widget.usuarios!){
                                if(ponto["profissional"] == usuario.email){
                                  temp = HorarioProfissional(usuario.nomeProfissional , ponto["horario_inicio"], ponto["horario_fim"], ponto["dia"], ponto["mes"], ponto["ano"], ponto["compareceu"]);
                                }
                              }
                            }else{
                              temp = HorarioProfissional(widget.usuario.nomeProfissional , ponto["horario_inicio"], ponto["horario_fim"], ponto["dia"], ponto["mes"], ponto["ano"], ponto["compareceu"]);
                            }

                            pontoProfissional.add(temp);
                          }

                          return ListView.builder(
                              scrollDirection: Axis.vertical,
                              itemCount: pontoProfissional.length,
                              itemBuilder: (BuildContext context, int index) {
                                var pontos = pontoProfissional[index];
                                var docBanco = data.docs[index];
                                return ListTile(
                                  onTap: () {
                                    showDialog(context: context, builder: (context) {
                                      return AlertDialog(
                                        title: Text("Deseja excluir esse ponto?"),
                                        actions: [
                                          TextButton(onPressed: () => Navigator.of(context).pop(), child: Text("Não")),
                                          TextButton(onPressed: () => deletarPonto(docBanco.id), child: Text("Sim")),

                                        ],
                                      );
                                    });
                                  },
                                    subtitle: Card(
                                      color: pontos.marcado
                                          ? Colors.green
                                          : Colors.red,
                                      child: Column(
                                          crossAxisAlignment: CrossAxisAlignment
                                              .start,
                                          children: [
                                            Padding(padding: EdgeInsetsDirectional.only(top: 10)),
                                            Row(
                                                mainAxisAlignment: MainAxisAlignment
                                                    .spaceAround,
                                                children: [

                                                  Text(pontos.nomeProfissional,
                                                    style: TextStyle(
                                                        fontSize: 20,
                                                        fontWeight: FontWeight
                                                            .bold,
                                                    color: CupertinoColors.white),),
                                                  Icon(pontos.marcado ? Icons.thumb_up_alt_sharp : Icons.thumb_down_alt_sharp, color: CupertinoColors.white,),
                                                ]
                                            ),
                                            Divider(color: CupertinoColors.white, height: 10, endIndent: 30, indent: 30, thickness: 2,),
                                            Row(
                                              children: [
                                                Padding(
                                                    padding: EdgeInsetsDirectional
                                                        .only(
                                                        start: 50)),
                                                Text("Dia: ", style: TextStyle(
                                                    fontSize: 15,
                                                    fontWeight: FontWeight
                                                        .bold,
                                                color: CupertinoColors.white)),
                                                Text(pontos.dia,
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        color: CupertinoColors.white)),
                                                Padding(
                                                    padding: EdgeInsetsDirectional
                                                        .only(
                                                        start: 20)),
                                                Text("Mês: ", style: TextStyle(
                                                    fontSize: 15,
                                                    fontWeight: FontWeight
                                                        .bold,
                                                    color: CupertinoColors.white)),
                                                Text(pontos.mes,
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        color: CupertinoColors.white)),
                                                Padding(
                                                    padding: EdgeInsetsDirectional
                                                        .only(
                                                        start: 30)),
                                                Text("Ano: ", style: TextStyle(
                                                    fontSize: 15,
                                                    fontWeight: FontWeight
                                                        .bold,
                                                    color: CupertinoColors.white)),
                                                Text(pontos.ano,
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        color: CupertinoColors.white)),
                                              ],
                                            ),

                                            Row(
                                              children: [
                                                Padding(
                                                    padding: EdgeInsetsDirectional
                                                        .only(
                                                        start: 15)),
                                                Text("Horario Inicio:",
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        fontWeight: FontWeight
                                                            .bold,
                                                        color: CupertinoColors.white)),
                                                Text(pontos.horaInicio,
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        color: CupertinoColors.white)),
                                                Padding(
                                                    padding: EdgeInsetsDirectional
                                                        .only(
                                                        start: 15)),
                                                Text("Horario Fim: ",
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        fontWeight: FontWeight
                                                            .bold,
                                                        color: CupertinoColors.white)),
                                                Text(pontos.horaFim, style: TextStyle(color: CupertinoColors.white),),

                                              ],
                                            ),
                                            Padding(padding: EdgeInsetsDirectional.only(bottom: 10)),

                                            /*Row(
                                              children: [
                                                Padding(
                                                    padding: EdgeInsetsDirectional
                                                        .only(
                                                        start: 10)),
                                                Text(
                                                  "Marcado: ", style: TextStyle(
                                                    fontWeight: FontWeight
                                                        .bold,
                                                    color: CupertinoColors.white),),
                                                Icon(pontos.marcado
                                                    ? Icons
                                                    .thumb_up_alt_sharp
                                                    : Icons
                                                    .thumb_down_alt_sharp,
                                                  size: 20, color: CupertinoColors.white,),
                                              ],
                                            )*/
                                          ]),
                                    )
                                );
                              });
                        }
                    )
                )
            )
            //),

          ],)
    );
/*ValueListenableBuilder<Stream<QuerySnapshot>>(
        valueListenable: widget.resultados,
        builder: (BuildContext context, Stream<QuerySnapshot> value, child) {
          return StreamBuilder<QuerySnapshot>(stream: value,
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshot) {
                if(!snapshot.hasData){
                  return Padding(padding: EdgeInsetsDirectional.only(top: 30),
                      child:  Center(child: CircularProgressIndicator(),)
                  );
                }
                if (snapshot.hasError) {
                  return Padding(padding: EdgeInsetsDirectional.only(top: 30),
                      child:  Text("Não foi possível carregar os dados", style: TextStyle(fontSize: 20, color: CupertinoColors.white), textAlign: TextAlign.center,)
                  );
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Padding(padding: EdgeInsetsDirectional.only(top: 30),
                   child:  Text("Carregando...", style: TextStyle(fontSize: 20, color: CupertinoColors.white), textAlign: TextAlign.center,)
                  );
                }

                final data = snapshot.requireData;
                if(data.docs.isEmpty){
                  return Padding(padding: EdgeInsetsDirectional.only(top: 30),
                    child: Text("Sem dados", style: TextStyle(fontSize: 20, color: CupertinoColors.white), textAlign: TextAlign.center,),
                  );
                }

                return ListView.builder(
                    scrollDirection: Axis.vertical,
                    itemCount: data.size,
                    itemBuilder: (BuildContext context, int index) {
                      return Container(

                          height: 110,
                          child: Card(
                            color: data.docs[index]['compareceu']
                                ? Colors.green
                                : Colors.red,
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                      mainAxisAlignment: MainAxisAlignment
                                          .center,
                                      children: [

                                        Text(data.docs[index]['profissional'],
                                          style: TextStyle(fontSize: 20,
                                              fontWeight: FontWeight.bold),),
                                      ]
                                  ),
                                  Row(
                                    children: [
                                      Padding(
                                          padding: EdgeInsetsDirectional.only(
                                              start: 10)),
                                      Text("Dia: ", style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold)),
                                      Text(data.docs[index]['dia'],
                                          style: TextStyle(fontSize: 15)),
                                      Padding(
                                          padding: EdgeInsetsDirectional.only(
                                              start: 20)),
                                      Text("Mês: ", style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold)),
                                      Text(data.docs[index]['mes'],
                                          style: TextStyle(fontSize: 15)),
                                      Padding(
                                          padding: EdgeInsetsDirectional.only(
                                              start: 30)),
                                      Text("Ano: ", style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold)),
                                      Text(data.docs[index]['ano'],
                                          style: TextStyle(fontSize: 15)),
                                    ],
                                  ),

                                  Row(
                                    children: [
                                      Padding(
                                          padding: EdgeInsetsDirectional.only(
                                              start: 10)),
                                      Text("Horario Inicio:", style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold)),
                                      Text(data.docs[index]['horario_inicio'],
                                          style: TextStyle(fontSize: 15)),
                                      Padding(
                                          padding: EdgeInsetsDirectional.only(
                                              start: 15)),
                                      Text("Horario Fim: ", style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold)),
                                      Text(data.docs[index]['horario_fim']),
                                    ],
                                  ),


                                  Row(
                                    children: [
                                      Padding(
                                          padding: EdgeInsetsDirectional.only(
                                              start: 10)),
                                      Text("Marcado: ", style: TextStyle(
                                          fontWeight: FontWeight.bold),),
                                      Icon(data.docs[index]['compareceu'] ? Icons
                                          .thumb_up_alt_sharp : Icons
                                          .thumb_down_alt_sharp, size: 20,),
                                    ],
                                  )
                                ]),
                          )
                      );
                    });
              }
          );*/

    /*return ValueListenableBuilder<List<HorarioProfissional>>(
        valueListenable: widget.horario,
        builder:(BuildContext context, List<HorarioProfissional> value, child) {
          return ListView.builder(
              scrollDirection: Axis.vertical,
              itemCount: widget.horario.value.length,
              itemBuilder: (BuildContext context, int index) {
                return Container(

                  height: 110,
                  child: Card(
                    color: value.elementAt(index).marcado ? Colors.green : Colors.red,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [

                            Text(value.elementAt(index).nomeProfissional,style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                          ]
                        ),
                        Row(
                          children: [
                            Padding(padding: EdgeInsetsDirectional.only(start:10)),
                            Text("Dia: ", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)), Text(value.elementAt(index).dia, style: TextStyle(fontSize: 15)),
                            Padding(padding: EdgeInsetsDirectional.only(start:20)),
                            Text("Mês: ", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)), Text(value.elementAt(index).mes, style: TextStyle(fontSize: 15)),
                            Padding(padding: EdgeInsetsDirectional.only(start:30)),
                            Text("Ano: ", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)), Text(value.elementAt(index).ano, style: TextStyle(fontSize: 15)),
                          ],
                        ),

                        Row(
                          children: [
                            Padding(padding: EdgeInsetsDirectional.only(start:10)),
                            Text("Horario Inicio:", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)), Text(value.elementAt(index).horaInicio, style: TextStyle(fontSize: 15)),
                            Padding(padding: EdgeInsetsDirectional.only(start:15)),
                            Text("Horario Fim: ", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)), Text(value.elementAt(index).horaFim),
                          ],
                        ),


                        Row(
                          children: [
                            Padding(padding: EdgeInsetsDirectional.only(start:10)),
                            Text("Marcado: ", style: TextStyle(fontWeight: FontWeight.bold),),
                            Icon(value.elementAt(index).marcado ? Icons.thumb_up_alt_sharp: Icons.thumb_down_alt_sharp, size: 20,),
                          ],
                        )
                      ]),
                  )
                );
              }
          );
        });
        });*/
    //}
//}
  }
}
