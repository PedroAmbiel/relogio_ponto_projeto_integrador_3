import 'package:app2_projeto_integrador_3/models/horario_profissional.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class CardHorarioRelatorio extends StatefulWidget{
  CardHorarioRelatorio({super.key,  required this.resultados});

  //final ValueNotifier<List<HorarioProfissional>> horario;
  ValueNotifier<Stream<QuerySnapshot>> resultados = ValueNotifier(Stream.empty());

  @override
  State<CardHorarioRelatorio> createState() => _CardHorarioRelatorio();

}

class _CardHorarioRelatorio extends State<CardHorarioRelatorio> {
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Stream<QuerySnapshot>>(
        valueListenable: widget.resultados,
        builder: (BuildContext context, Stream<QuerySnapshot> value, child) {
          return StreamBuilder<QuerySnapshot>(stream: value,
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshot) {
                if(!snapshot.hasData){
                  return Text("Carregando...");
                }
                if (snapshot.hasError) {
                  return Text("Não foi possível carregar os dados");
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  Text("Carregando...");
                }

                final data = snapshot.requireData;

                return ListView.builder(
                    scrollDirection: Axis.vertical,
                    itemCount: data.size,
                    itemBuilder: (BuildContext context, int index) {
                      return Container(

                          height: 110,
                          child: Card(
                            color: data.docs[index]['compareceu']
                                ? Colors.green
                                : Colors.red,
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                      mainAxisAlignment: MainAxisAlignment
                                          .center,
                                      children: [

                                        Text(data.docs[index]['profissional'],
                                          style: TextStyle(fontSize: 20,
                                              fontWeight: FontWeight.bold),),
                                      ]
                                  ),
                                  Row(
                                    children: [
                                      Padding(
                                          padding: EdgeInsetsDirectional.only(
                                              start: 10)),
                                      Text("Dia: ", style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold)),
                                      Text(data.docs[index]['dia'],
                                          style: TextStyle(fontSize: 15)),
                                      Padding(
                                          padding: EdgeInsetsDirectional.only(
                                              start: 20)),
                                      Text("Mês: ", style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold)),
                                      Text(data.docs[index]['mes'],
                                          style: TextStyle(fontSize: 15)),
                                      Padding(
                                          padding: EdgeInsetsDirectional.only(
                                              start: 30)),
                                      Text("Ano: ", style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold)),
                                      Text(data.docs[index]['ano'],
                                          style: TextStyle(fontSize: 15)),
                                    ],
                                  ),

                                  Row(
                                    children: [
                                      Padding(
                                          padding: EdgeInsetsDirectional.only(
                                              start: 10)),
                                      Text("Horario Inicio:", style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold)),
                                      Text(data.docs[index]['horario_inicio'],
                                          style: TextStyle(fontSize: 15)),
                                      Padding(
                                          padding: EdgeInsetsDirectional.only(
                                              start: 15)),
                                      Text("Horario Fim: ", style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold)),
                                      Text(data.docs[index]['horario_fim']),
                                    ],
                                  ),


                                  Row(
                                    children: [
                                      Padding(
                                          padding: EdgeInsetsDirectional.only(
                                              start: 10)),
                                      Text("Marcado: ", style: TextStyle(
                                          fontWeight: FontWeight.bold),),
                                      Icon(data.docs[index]['compareceu'] ? Icons
                                          .thumb_up_alt_sharp : Icons
                                          .thumb_down_alt_sharp, size: 20,),
                                    ],
                                  )
                                ]),
                          )
                      );
                    });
              }
          );

          /*return ValueListenableBuilder<List<HorarioProfissional>>(
        valueListenable: widget.horario,
        builder:(BuildContext context, List<HorarioProfissional> value, child) {
          return ListView.builder(
              scrollDirection: Axis.vertical,
              itemCount: widget.horario.value.length,
              itemBuilder: (BuildContext context, int index) {
                return Container(

                  height: 110,
                  child: Card(
                    color: value.elementAt(index).marcado ? Colors.green : Colors.red,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [

                            Text(value.elementAt(index).nomeProfissional,style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                          ]
                        ),
                        Row(
                          children: [
                            Padding(padding: EdgeInsetsDirectional.only(start:10)),
                            Text("Dia: ", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)), Text(value.elementAt(index).dia, style: TextStyle(fontSize: 15)),
                            Padding(padding: EdgeInsetsDirectional.only(start:20)),
                            Text("Mês: ", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)), Text(value.elementAt(index).mes, style: TextStyle(fontSize: 15)),
                            Padding(padding: EdgeInsetsDirectional.only(start:30)),
                            Text("Ano: ", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)), Text(value.elementAt(index).ano, style: TextStyle(fontSize: 15)),
                          ],
                        ),

                        Row(
                          children: [
                            Padding(padding: EdgeInsetsDirectional.only(start:10)),
                            Text("Horario Inicio:", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)), Text(value.elementAt(index).horaInicio, style: TextStyle(fontSize: 15)),
                            Padding(padding: EdgeInsetsDirectional.only(start:15)),
                            Text("Horario Fim: ", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)), Text(value.elementAt(index).horaFim),
                          ],
                        ),


                        Row(
                          children: [
                            Padding(padding: EdgeInsetsDirectional.only(start:10)),
                            Text("Marcado: ", style: TextStyle(fontWeight: FontWeight.bold),),
                            Icon(value.elementAt(index).marcado ? Icons.thumb_up_alt_sharp: Icons.thumb_down_alt_sharp, size: 20,),
                          ],
                        )
                      ]),
                  )
                );
              }
          );
        });*/
        });
  }
}

