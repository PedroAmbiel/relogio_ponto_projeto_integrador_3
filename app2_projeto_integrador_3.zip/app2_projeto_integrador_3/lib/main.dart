import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    home: Home(),
  ));
}


class Home extends StatefulWidget{
  const Home({super.key});
  @override
  State<Home> createState() => _Home();
}



class _Home extends State<Home> {

  var _horarios = ["8:00", "8:30", "9:00", "9:30","10:00", "10:30","11:00", "11:30","12:00", "12:30","13:00", "13:30","14:00", "14:30","15:00", "15:30","16:00", "16:30","17:00", "17:30","18:00", "18:30","19:00", "19:30","20:00", "20:30", "21:00", "21:30", "22:00", "22:30"];
  String _horarioInicioSelecionado = "8:00";
  String _horarioFimSelecionado = "8:00";
  bool _pontoVerificado = false;

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.blue[900],
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Text("Cadastro de \n Ponto Manual", style: TextStyle(fontSize: 30, color: Colors.white,), textAlign: TextAlign.center,),

            Container(height: 50, width: 200, decoration: BoxDecoration(color: Colors.white),),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 100,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),),
                  child: TextFormField(
                    controller: null,
                    keyboardType: TextInputType.numberWithOptions(decimal: false),
                    decoration: InputDecoration(labelText: "Dia",
                        labelStyle: TextStyle(color: Colors.white, fontSize: 16),
                        enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white)),
                        focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.deepOrangeAccent)),
                    ),
                    style: TextStyle(color: Colors.black),
                  ),
                ),
                Padding(padding: EdgeInsetsDirectional.only(start: 10)),
                Container(
                  width: 100,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),),
                  child: TextFormField(
                    controller: null,
                    keyboardType: TextInputType.numberWithOptions(decimal: false),
                    decoration: InputDecoration(labelText: "Mês",
                      labelStyle: TextStyle(color: Colors.white, fontSize: 16),
                      enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white)),
                      focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.deepOrangeAccent)),
                    ),
                    style: TextStyle(color: Colors.black),
                  ),
                ),
                Padding(padding: EdgeInsetsDirectional.only(start: 10)),
                Container(
                  width: 100,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),),
                  child: TextFormField(
                    controller: null,
                    keyboardType: TextInputType.numberWithOptions(decimal: false),
                    decoration: InputDecoration(labelText: "Ano",
                      labelStyle: TextStyle(color: Colors.white, fontSize: 16),
                      enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white)),
                      focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.deepOrangeAccent)),
                    ),
                    style: TextStyle(color: Colors.black),
                  ),
                ),
              ],
            ),

            Wrap(
              direction: Axis.vertical,
              crossAxisAlignment: WrapCrossAlignment.center,
              spacing: -15,
              children: [
                Text("Marcado?", style: TextStyle(color: Colors.white),),
                Checkbox(
                  side: BorderSide(color: Colors.white),
                  activeColor: Colors.deepOrangeAccent,
                  value: _pontoVerificado,
                  onChanged: (bool? value) {
                    setState(() {
                      _pontoVerificado = value ?? false;
                      print(_pontoVerificado);
                    });
                  },
                ),

              ],
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Text("Horário Inicio", style: TextStyle(fontSize: 15, color: Colors.white),),
                    Container(
                      alignment: Alignment.center,
                      width: 100,
                      child: DropdownButton<String>(
                        dropdownColor: Colors.black,
                        iconEnabledColor: Colors.white,
                        underline: Container(decoration: BoxDecoration(border: Border.all(color: Colors.deepOrangeAccent)),),
                        alignment: Alignment.center,
                        style: TextStyle(color: Colors.white, fontSize: 18),
                        items: _horarios.map((String item) {
                          return DropdownMenuItem(
                            child: Text(item),
                            value: item,
                          );
                        }).toList(),
                        onChanged: (String? newValue){
                          setState(() {
                            _horarioInicioSelecionado = newValue!;
                            print(_horarioInicioSelecionado);
                          });
                        },
                        value: _horarioInicioSelecionado,
                      ),
                    )
                ]),

                Padding(padding: EdgeInsetsDirectional.only(start: 20, end: 20)),
                Column(
                    children: [
                      Text("Horário Fim", style: TextStyle(fontSize: 15, color: Colors.white),),
                      Container(
                        alignment: Alignment.center,
                        child: DropdownButton<String>(
                          alignment: Alignment.center,
                          dropdownColor: Colors.black,
                          iconEnabledColor: Colors.white,
                          underline: Container(decoration: BoxDecoration(border: Border.all(color: Colors.deepOrangeAccent)),),
                          style: TextStyle(color: Colors.white, fontSize: 18),
                          items: _horarios.map((String item) {
                            return DropdownMenuItem(
                              child: Text(item),
                              value: item,
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              _horarioFimSelecionado = newValue!;
                              print(_horarioFimSelecionado);
                            });
                          },
                          value: _horarioFimSelecionado,
                        ),
                      )
                    ]),
              ],
            ),
            Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: screenWidth * 0.3,
                    child: FloatingActionButton(
                      onPressed: null,
                      backgroundColor: Colors.deepOrangeAccent[200],
                      tooltip: "Inserir ponto",
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset("assets/add.png", width: 20, height: 20, color: Colors.white,),
                          Padding(padding: EdgeInsets.symmetric(horizontal: 5)),
                          Text(style: TextStyle(fontSize: 16, color: Colors.white), "Inserir"),
                        ],
                      ),
                    ),
                  ),
                  Padding(padding: EdgeInsets.all(10.0)),

                  SizedBox(
                    width: screenWidth * 0.3,
                    child: FloatingActionButton(
                      onPressed: null,
                      backgroundColor: Colors.deepOrangeAccent[200],
                      tooltip: "Deletar ponto",
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset("assets/minus.png", width: 20, height: 20, color: Colors.white,),
                          Padding(padding: EdgeInsets.symmetric(horizontal: 5)),
                          Text(style: TextStyle(fontSize: 16, color: Colors.white), "Deletar"),
                        ],
                      ),
                    ),
                  ),
                ]),
          ],
        )
    );
  }
}
