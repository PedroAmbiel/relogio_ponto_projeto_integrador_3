import 'package:app2_projeto_integrador_3/cadastroPonto.dart';
import 'package:app2_projeto_integrador_3/relatorioPonto.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MaterialApp(
    localizationsDelegates: [
      GlobalMaterialLocalizations.delegate,
      DefaultWidgetsLocalizations.delegate
    ],
    supportedLocales: [const Locale('pt', 'BR')],
    home: App(),
    debugShowCheckedModeBanner: false,
  ));
}


class App extends StatefulWidget{
  const App({super.key});
  @override
  State<App> createState() => _App();
}


class _App extends State<App> {
  int currentPageIndex = 0;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar:
      NavigationBarTheme(
        data: NavigationBarThemeData(
          labelTextStyle: MaterialStateProperty.resolveWith<TextStyle>(
                (Set<MaterialState> states) => states.contains(MaterialState.selected)
                ? const TextStyle(color: Colors.white)
                : const TextStyle(color: Colors.white),
          ),
        ),
        child: NavigationBar(
          backgroundColor: Colors.blue[900],
          indicatorColor: CupertinoColors.white,
          surfaceTintColor: Colors.black,
          labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
          height: 70,
          onDestinationSelected: (int index) {
            setState(() {
              currentPageIndex = index;
            });
          },
          selectedIndex: currentPageIndex,
          destinations: [
            NavigationDestination(
              selectedIcon: Image.asset("assets/pencil.png", width: 20, color: CupertinoColors.black,),
              icon: Image.asset("assets/pencil.png", width: 20, color: CupertinoColors.white,),
              label: 'Cadastrar',
            ),
            NavigationDestination(
              selectedIcon: Image.asset("assets/clipboard.png", width: 20, color: CupertinoColors.black,),
              icon: Image.asset("assets/clipboard.png", width: 20, color: CupertinoColors.white,),
              label: 'Relatório',
            ),
          ],
        ),
      ),
      body: <Widget> [
        Home(),
        Relatorio(),
      ][currentPageIndex],
    );
  }


}

