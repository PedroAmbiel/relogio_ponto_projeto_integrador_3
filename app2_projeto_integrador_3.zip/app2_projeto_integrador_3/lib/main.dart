import 'package:app2_projeto_integrador_3/cadastroPonto.dart';
import 'package:app2_projeto_integrador_3/navigationBar.dart';
import 'package:app2_projeto_integrador_3/relatorioPonto.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    home: App(),
  ));
}


class App extends StatefulWidget{
  const App({super.key});
  @override
  State<App> createState() => _App();
}



class _App extends State<App> {
  int currentPageIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: NavigationBar(
        backgroundColor: Colors.deepOrangeAccent,
        indicatorColor: CupertinoColors.black,
        surfaceTintColor: Colors.black,
        labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
        height: 60,
        onDestinationSelected: (int index) {
          setState(() {
            currentPageIndex = index;
          });
        },
        selectedIndex: currentPageIndex,
        destinations: [
          NavigationDestination(
            selectedIcon: Image.asset("assets/pencil.png", width: 20, color: CupertinoColors.white,),
            icon: Image.asset("assets/pencil.png", width: 20, color: CupertinoColors.white,),
            label: 'Cadastrar',
          ),
          NavigationDestination(
            selectedIcon: Image.asset("assets/clipboard.png", width: 20, color: CupertinoColors.white,),
            icon: Image.asset("assets/clipboard.png", width: 20, color: CupertinoColors.white,),
            label: 'Relatório',
          ),
        ],
      ),
      body: <Widget> [
        Home(),
        Relatorio(),
      ][currentPageIndex],
    );
  }


}

