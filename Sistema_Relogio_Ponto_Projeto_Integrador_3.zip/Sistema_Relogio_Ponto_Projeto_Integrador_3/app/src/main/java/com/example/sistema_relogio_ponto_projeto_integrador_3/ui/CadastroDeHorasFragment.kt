package com.example.sistema_relogio_ponto_projeto_integrador_3.ui

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.sistema_relogio_ponto_projeto_integrador_3.TelaPrincipalAplicativo
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentCadastroDeHorasBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class CadastroDeHorasFragment : Fragment() {

    private var _binding: FragmentCadastroDeHorasBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCadastroDeHorasBinding.inflate(inflater, container, false)
        return _binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        inicializarCalendario()
    }

    private fun inicializarCalendario(){
        binding.calendar.setOnDateChangeListener { _, year, month, dayOfMonth ->
            val calendar = Calendar.getInstance()
            calendar.set(year, month, dayOfMonth)

            val selectedDate = calendar.get(Calendar.DAY_OF_WEEK)

            if(selectedDate == Calendar.SATURDAY || selectedDate == Calendar.SUNDAY) {
                Toast.makeText(activity, "Não é possível selecionar finais de semana", Toast.LENGTH_SHORT).show();
            }
        }
    }

}