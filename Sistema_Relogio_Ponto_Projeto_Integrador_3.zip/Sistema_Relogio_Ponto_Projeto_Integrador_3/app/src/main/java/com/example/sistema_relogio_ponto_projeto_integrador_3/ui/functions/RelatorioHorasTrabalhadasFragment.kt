package com.example.sistema_relogio_ponto_projeto_integrador_3.ui.functions

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListAdapter
import android.widget.Toast
import androidx.activity.addCallback
import androidx.core.view.get
import androidx.core.view.isVisible
import androidx.navigation.fragment.findNavController
import com.example.sistema_relogio_ponto_projeto_integrador_3.R
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentCadastroDeHorasBinding
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentRelatorioHorasTrabalhadasBinding
import com.example.sistema_relogio_ponto_projeto_integrador_3.listAdapter.ListAgendaProfessorAdapter
import com.example.sistema_relogio_ponto_projeto_integrador_3.models.AgendaProfessor
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.Calendar

class RelatorioHorasTrabalhadasFragment : Fragment() {

    private var _binding : FragmentRelatorioHorasTrabalhadasBinding? = null
    private val  binding get() = _binding!!
    private lateinit var db : FirebaseFirestore
    private lateinit var auth : FirebaseAuth

    private lateinit var listAdapter : ListAdapter
    private lateinit var listData : AgendaProfessor
    var dataArrayList = ArrayList<AgendaProfessor?>()

    private var diaSelecionado : Int? = null
    private var mesSelecionado : Int? = null
    private var anoSelecionado : Int? = null


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentRelatorioHorasTrabalhadasBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        auth = Firebase.auth
        db = Firebase.firestore

        inicializarBotoes()
        carregarHorariosPendentesDeHoje(Calendar.getInstance().timeInMillis)
        requireActivity().onBackPressedDispatcher.addCallback {
            findNavController().popBackStack()
        }
    }

    private fun inicializarBotoes(){
        binding.toolbar.setOnClickListener{
            findNavController().popBackStack()
        }

        /*binding.btnGerarRelatorio.setOnClickListener {
            if(diaSelecionado != null && mesSelecionado != null && anoSelecionado != null){
                carregarHorariosPendentesDeHoje()
            }else{
                Toast.makeText(activity, "Selecione uma data!", Toast.LENGTH_SHORT).show()
            }
        }*/

        binding.calendarDias.setOnDateChangeListener { it, year, month, dayOfMonth ->
            val calendar = Calendar.getInstance()
            calendar.set(year, month, dayOfMonth)

            val selectedDate = calendar.get(Calendar.DAY_OF_WEEK)
            it.date = calendar.timeInMillis
            carregarHorariosPendentesDeHoje(it.date)
            //Toast.makeText(activity, "Dia Semana Selecionada ${binding.calendar.date}", Toast.LENGTH_SHORT).show();
        }
    }

    private fun carregarHorariosPendentesDeHoje(data : Long){
        /*val calendar = Calendar.getInstance()
        val diaAtual = calendar.get(Calendar.DAY_OF_MONTH)
        val mesAtual = calendar.get(Calendar.MONTH).plus(1)
        val anoAtual = calendar.get(Calendar.YEAR)*/

        //val dataSelecionada = binding.calendarDias.date
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = data

        //val calendar = Calendar.getInstance()
        val listaDePontos = mutableListOf<AgendaProfessor>()



        db.collection("horario_profissional")
            .whereEqualTo("dia", calendar.get(Calendar.DAY_OF_MONTH).toString())
            .whereEqualTo("mes", calendar.get(Calendar.MONTH).plus(1).toString())
            .whereEqualTo("ano", calendar.get(Calendar.YEAR).toString())
            .whereEqualTo("profissional", auth.currentUser?.email.toString())
            .get()
            .addOnSuccessListener {documents ->
                if(documents.isEmpty){
                    binding.txtSemHorario.isVisible=true
                    binding.listAgendaProfissional.isVisible = false
                    //Toast.makeText(activity, "Vazio", Toast.LENGTH_SHORT).show()
                }else{
                    for(documento in documents){
                        val agenda = AgendaProfessor(
                            ano = documento.get("ano").toString(),
                            mes = documento.get("mes").toString(),
                            dia = documento.get("dia").toString(),
                            horario_inicio = documento.get("horario_inicio").toString(),
                            horario_fim = documento.get("horario_fim").toString(),
                            profissional = documento.get("profissional").toString(),
                            compareceu = documento.get("compareceu").toString().toBoolean())
                        listaDePontos.add(agenda)
                    }



                    criarListaHorario(listaDePontos)
                }


            }


    }

    private fun criarListaHorario(dadosBanco : List<AgendaProfessor>){
        dataArrayList.clear()

        for (documentos in dadosBanco){
            listData = documentos
            dataArrayList.add(listData)
        }
        dataArrayList.sortByDescending { it?.horario_inicio }
        listAdapter = ListAgendaProfessorAdapter(requireContext(), dataArrayList)
        binding.listAgendaProfissional.adapter = listAdapter
        binding.listAgendaProfissional.isClickable = false
        binding.listAgendaProfissional.isVisible = true

    }

}