package com.example.sistema_relogio_ponto_projeto_integrador_3.listAdapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.core.graphics.drawable.toDrawable
import androidx.core.graphics.toColor
import androidx.core.graphics.toColorInt
import com.example.sistema_relogio_ponto_projeto_integrador_3.R
import com.example.sistema_relogio_ponto_projeto_integrador_3.models.AgendaProfessor
import com.google.android.material.imageview.ShapeableImageView

class ListAgendaProfessorAdapter(context: Context, dadosArrayList: ArrayList<AgendaProfessor?>?) :
    ArrayAdapter<AgendaProfessor?>(context, R.layout.list_agenda_profissional, dadosArrayList!!){

    @SuppressLint("ResourceAsColor")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        var view = convertView
        val dadosLista = getItem(position)

        if(view == null){
            view = LayoutInflater.from(context).inflate(R.layout.list_agenda_profissional, parent, false)
        }

        val horarioInicioLista = view!!.findViewById<TextView>(R.id.listHoraInicio)
        val horarioFim = view.findViewById<TextView>(R.id.listHoraFim)
        val compareceu = view.findViewById<TextView>(R.id.listCompareceu)


        "Horario inicio: ${dadosLista!!.horario_inicio}".also { horarioInicioLista.text = it }
        "Horario fim: ${dadosLista.horario_fim}".also { horarioFim.text = it }
        compareceu.text = "Compareceu: " + if(dadosLista.compareceu){"Sim"}else{"Não"}
        return view
    }
}