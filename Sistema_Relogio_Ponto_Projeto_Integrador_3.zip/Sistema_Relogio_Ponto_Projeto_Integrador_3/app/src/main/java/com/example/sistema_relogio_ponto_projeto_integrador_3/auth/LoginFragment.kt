package com.example.sistema_relogio_ponto_projeto_integrador_3.auth

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.sistema_relogio_ponto_projeto_integrador_3.R
import com.example.sistema_relogio_ponto_projeto_integrador_3.TelaPrincipalAplicativo
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentLoginBinding
import com.example.sistema_relogio_ponto_projeto_integrador_3.main.MenuPrincipalFragmentDirections

class LoginFragment : Fragment() {
    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        irPraMenuPrincipal()
        irParaCriarConta()
        irParaRecuperarSenha()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null;
    }


    private fun irPraMenuPrincipal(){
        val action = LoginFragmentDirections.actionGlobalMenuPrincipalFragment()
        binding.btnAccess.setOnClickListener{
            findNavController().navigate(action)
        }
    }

    private fun irParaCriarConta(){
        val action = LoginFragmentDirections.actionLoginFragmentToCriarContaFragment()
        binding.btnRegistrar.setOnClickListener{
            findNavController().navigate(action)
        }
    }

    private fun irParaRecuperarSenha(){
        val action = LoginFragmentDirections.actionLoginFragmentToRecuperarSenhaFragment()
        binding.btnRecuperar.setOnClickListener{
            findNavController().navigate(action)
        }
    }

}