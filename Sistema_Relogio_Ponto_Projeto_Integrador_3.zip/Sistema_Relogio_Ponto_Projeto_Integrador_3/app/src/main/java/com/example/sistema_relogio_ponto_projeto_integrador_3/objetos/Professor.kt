package com.example.sistema_relogio_ponto_projeto_integrador_3.objetos

class Professor {
}