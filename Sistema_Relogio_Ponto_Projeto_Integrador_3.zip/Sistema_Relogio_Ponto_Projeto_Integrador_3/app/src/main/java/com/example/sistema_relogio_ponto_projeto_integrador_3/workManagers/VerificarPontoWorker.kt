package com.example.sistema_relogio_ponto_projeto_integrador_3.workManagers

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Context.NOTIFICATION_SERVICE
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.sistema_relogio_ponto_projeto_integrador_3.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.sql.Time
import java.util.Calendar

class VerificarPontoWorker(private val appContext : Context, private val params: WorkerParameters)
    : CoroutineWorker(appContext, params) {

    private val PRIMARY_CHANNEL_ID = "primary_channel_id"
    private val NOTIFICATION_ID = 0
    private var notificationWorkManager : NotificationManager? = null


    private lateinit var auth : FirebaseAuth
    private lateinit var db : FirebaseFirestore

    override suspend fun doWork(): Result {
        auth = Firebase.auth
        db = Firebase.firestore

        Log.i("threadNotificacao", "Entrou no WORKER!!!")

        if(auth.currentUser?.email != null && ContextCompat.checkSelfPermission(appContext, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            Log.i("threadNotificacao", "Verificar ponto disponivel com email")
            consultarPontosMarcados()
        }else{
            Log.i("threadNotificacao", "Verificar ponto disponivel com email NULL")
        }


        return Result.success()
    }

    private fun sendNotification(mensagemNotificacao : String) {
        val notificatioBuilder : NotificationCompat.Builder = getNotificationBuilder(mensagemNotificacao)
        notificationWorkManager?.notify(NOTIFICATION_ID, notificatioBuilder.build())
    }

    private fun getNotificationBuilder(mensagemNotificacao : String): NotificationCompat.Builder {
        return NotificationCompat.Builder(applicationContext, PRIMARY_CHANNEL_ID)
            .setSmallIcon(R.drawable.puccamp_brasao)
            .setContentTitle("Fique Antento!")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentText(mensagemNotificacao)
    }

    private fun createChannel() {
        notificationWorkManager = applicationContext.getSystemService(NOTIFICATION_SERVICE) as NotificationManager

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val notificationChannel = NotificationChannel(
                PRIMARY_CHANNEL_ID,
                "Notificações de Ponto",
                NotificationManager.IMPORTANCE_DEFAULT
            )

            notificationChannel.description = "Canal de Notificação"

            notificationChannel.enableLights(true)
            notificationChannel.lightColor = Color.RED
            notificationChannel.enableVibration(true)

            notificationWorkManager?.createNotificationChannel(notificationChannel)
        }
    }

    private fun consultarPontosMarcados(){
        val calendar = Calendar.getInstance()
        val diaAtual = calendar.get(Calendar.DAY_OF_MONTH)
        val mesAtual = calendar.get(Calendar.MONTH).plus(1)
        val anoAtual = calendar.get(Calendar.YEAR)

        var horaAtual: String =calendar.get(Calendar.HOUR_OF_DAY).toString()
        var minutoAtual: String = calendar.get(Calendar.MINUTE).toString()
        if(horaAtual.length == 1){horaAtual = "0$horaAtual"}
        if(minutoAtual.length == 1){minutoAtual = "0$minutoAtual"}

        val horarioAtualCompleto = "$horaAtual:$minutoAtual"

        db.collection("horario_profissional")
            .whereEqualTo("dia", diaAtual.toString())
            .whereEqualTo("mes", mesAtual.toString())
            .whereEqualTo("ano", anoAtual.toString())
            .whereEqualTo("profissional", auth.currentUser?.email.toString())
            .whereEqualTo("compareceu", false)
            .get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    for(documento in documents){
                        if(Time.valueOf("$horarioAtualCompleto:00").time.minus(Time.valueOf("${documento.get("horario_inicio").toString()}:00").time) <= 600000){
                            createChannel()
                            sendNotification("Horário das ${documento.get("horario_inicio")}/${documento.get("horario_fim")} se aproximando. Não se esqueça de marcar o ponto!")
                        }
                    }

                }
            }
            .addOnFailureListener {
                Toast.makeText(appContext, "Não foi possível verificar se existe ponto em aberto", Toast.LENGTH_SHORT).show()
            }
    }

}