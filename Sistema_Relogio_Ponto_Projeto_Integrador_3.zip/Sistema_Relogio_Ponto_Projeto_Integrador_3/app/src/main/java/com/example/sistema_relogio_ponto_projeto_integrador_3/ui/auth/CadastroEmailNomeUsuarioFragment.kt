package com.example.sistema_relogio_ponto_projeto_integrador_3.ui.auth

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.addCallback
import androidx.navigation.fragment.findNavController
import com.example.sistema_relogio_ponto_projeto_integrador_3.R
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentCadastroEmailNomeUsuarioBinding
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentCriarContaBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.android.awaitFrame
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay

class CadastroEmailNomeUsuarioFragment : Fragment() {
    private var _binding: FragmentCadastroEmailNomeUsuarioBinding? = null
    private val binding get() = _binding!!
    private lateinit var auth : FirebaseAuth
    private lateinit var db : FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
       _binding = FragmentCadastroEmailNomeUsuarioBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null;
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        auth = Firebase.auth
        db = Firebase.firestore
        inicializarBotoes()
        requireActivity().onBackPressedDispatcher.addCallback {
            findNavController().popBackStack()
        }
    }

    private fun inicializarBotoes(){
        binding.btnSalvar.setOnClickListener {
            val nome = binding.edtNome.text.toString().trim()
            val sobrenome = binding.edtSobrenome.text.toString().trim()


            if (validarNomeSobrenome(nome, sobrenome))
                adicionarContaNomeUsuario(nome, sobrenome)
        }

        binding.toolbar.setOnClickListener {
            findNavController().popBackStack()
        }
    }

    private fun validarNomeSobrenome(nome: String, sobrenome: String) : Boolean {
        if(nome.isBlank() || sobrenome.isBlank()){
            Toast.makeText(activity, "Preencha os campos NOME e SOBRENOME", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun adicionarContaNomeUsuario(nome : String, sobrenome : String){
        val novoUsuarioEmail = hashMapOf(
            "usuario" to (auth.currentUser?.email.toString()),
            "nome" to nome,
            "sobrenome" to sobrenome
        )


        db.collection("email_usuario")
            .add(novoUsuarioEmail)
            .addOnSuccessListener {
                findNavController().navigate(R.id.action_cadastroEmailNomeUsuarioFragment_to_menuPrincipalFragment)
            }
            .addOnFailureListener{
                Toast.makeText(activity, "Erro: ${it.message}", Toast.LENGTH_SHORT).show()
            }
    }





}