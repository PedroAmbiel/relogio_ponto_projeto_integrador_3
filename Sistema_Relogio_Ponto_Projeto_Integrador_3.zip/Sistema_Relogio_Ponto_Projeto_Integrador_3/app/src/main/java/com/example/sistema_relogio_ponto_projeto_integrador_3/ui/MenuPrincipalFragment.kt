package com.example.sistema_relogio_ponto_projeto_integrador_3.ui

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.example.sistema_relogio_ponto_projeto_integrador_3.R
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentMenuPrincipalBinding

class MenuPrincipalFragment : Fragment() {

    private var _binding: FragmentMenuPrincipalBinding? = null
    private val binding get() = _binding!!



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentMenuPrincipalBinding.inflate(inflater, container, false)
        return _binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        iniciarFragment()
    }

    private fun iniciarFragment(){
        adicionaUsuarioAoFragment()
        irParaTelaCadastroDeHoras()
        irParaTelaMarcarPonto()
    }

    private fun adicionaUsuarioAoFragment(){

        val message = arguments?.getString("data")
        binding.txtMainFragment.text = "Bem vindo,  ${message}"
        /*val data = arguments?.getString(ARG_DATA)
        val message = "Bem vindo, $data"

        binding.textView.text = message*/
    }

    private fun irParaTelaCadastroDeHoras(){
        val action = MenuPrincipalFragmentDirections.actionMenuPrincipalFragmentToCadastroDeHorasFragment()
        binding.btnCadastroHoras.setOnClickListener{
            findNavController().navigate(action)
        }
    }

    private fun irParaTelaMarcarPonto(){
        val action = MenuPrincipalFragmentDirections.actionMenuPrincipalFragmentToMarcarPontoFragment()
        binding.btnMarcarPonto.setOnClickListener{
            findNavController().navigate(action)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}