package com.example.sistema_relogio_ponto_projeto_integrador_3.models

data class AgendaProfessor (
    val ano: String,
    val mes: String,
    val dia : String,
    val compareceu : Boolean,
    val horario_fim : String,
    val horario_inicio : String,
    val profissional : String,
)