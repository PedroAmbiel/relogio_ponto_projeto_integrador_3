package com.example.sistema_relogio_ponto_projeto_integrador_3.ui.functions

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.addCallback
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.sistema_relogio_ponto_projeto_integrador_3.R
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentCadastroDeHorasBinding
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentMenuPrincipalBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.firestore
import java.util.Calendar
import java.sql.Timestamp
import java.time.LocalDate
import java.util.Date

class CadastroDeHorasFragment : Fragment() {

    private var _binding: FragmentCadastroDeHorasBinding? = null
    private val binding get() = _binding!!
    private lateinit var db : FirebaseFirestore
    private lateinit var auth : FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCadastroDeHorasBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        db = Firebase.firestore
        auth = Firebase.auth




        inicializarBotoes()
        voltarMenuPrincipal()
        requireActivity().onBackPressedDispatcher.addCallback {
            findNavController().popBackStack()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun inicializarBotoes(){
        binding.calendar.minDate = Date().time


        binding.btnCadastrarHora?.setOnClickListener {
            binding.btnCadastrarHora!!.isClickable = false
            validarHorarioInformado()
        }

        binding.calendar.setOnDateChangeListener { it, year, month, dayOfMonth ->
            val calendar = Calendar.getInstance()
            calendar.set(year, month, dayOfMonth)

            val selectedDate = calendar.get(Calendar.DAY_OF_WEEK)
            it.date = calendar.timeInMillis
            validarDiaSemanaSelecionado(selectedDate)


            //Toast.makeText(activity, "Dia Semana Selecionada ${binding.calendar.date}", Toast.LENGTH_SHORT).show();
        }
    }

    private fun validarDiaSemanaSelecionado(selectedDate : Int) : Boolean{
        if(selectedDate == Calendar.SATURDAY || selectedDate == Calendar.SUNDAY) {
            Toast.makeText(activity, "Não é possível selecionar finais de semana", Toast.LENGTH_SHORT).show();

            return false
        }
        return true
    }

    private fun validarHorarioSelecionado(hora : String, minuto : String) : Boolean{
        if((hora.isBlank() || hora.toInt() >= 24) || (minuto.isBlank() || minuto.toInt() >= 60 )){
            Toast.makeText(activity, "Horario inválido, exemplo de preenchimento 00:00/23:59", Toast.LENGTH_SHORT).show();
            return false
        }
        return true
    }

    private fun voltarMenuPrincipal(){
        binding.toolbar.setOnClickListener {
            findNavController().popBackStack()
        }
    }

    private fun validarHorarioInformado(){
        var hora = binding.edtxHora.text.toString()
        var minuto = binding.edtxMinuto.text.toString()
        val dataSelecionada = binding.calendar.date

        //Caso o horario e minuto seja preenchidos somente com um caracter concatena um 0 no começo
        if(hora.length == 1){hora = "0$hora"}
        if(minuto.length == 1){minuto = "0$minuto"}

        val calendar = Calendar.getInstance()
        calendar.timeInMillis = dataSelecionada

        var podeSalvar = true

        if(validarDiaSemanaSelecionado(dataSelecionada.toInt())
                && validarHorarioSelecionado(hora, minuto)) {

            db.collection("horario_profissional")
                .whereEqualTo("dia", calendar.get(Calendar.DAY_OF_MONTH).toString())
                .whereEqualTo("mes", calendar.get(Calendar.MONTH).plus(1).toString())
                .whereEqualTo("ano", calendar.get(Calendar.YEAR).toString())
                .get()
                .addOnSuccessListener { documents ->
                    if(documents.isEmpty){
                        podeSalvar = true
                    }
                    for (documento in documents) {
                        val horaDocumento = documento.get("horario_inicio").toString().split(":")[0].toInt()
                        val minutoDocumento = documento.get("horario_inicio").toString().split(":")[1].toInt()

                        if (horaDocumento == hora.toInt() || (minutoDocumento > minuto.toInt() && horaDocumento.plus(1) == hora.toInt())
                            || (minutoDocumento < minuto.toInt() && horaDocumento.minus(1) == hora.toInt())) {
                            Toast.makeText(activity,"Horário indísponível, as aulas devem ser marcadas de 1 em 1 hora",Toast.LENGTH_SHORT).show()
                            binding.btnCadastrarHora?.isClickable = true
                            podeSalvar = false
                        }


                    }
                    if(podeSalvar) {
                        adicionarDataHoraAtividade(hora, minuto, calendar)
                    }

                }
                .addOnFailureListener {
                    Toast.makeText(
                        activity,
                        "Não foi possível salvar o horário",
                        Toast.LENGTH_SHORT
                    ).show()
                }

        }


    }

    private fun adicionarDataHoraAtividade(hora : String, minuto: String, calendar : Calendar){
        val horarioInicio = "$hora:$minuto"
        val horarioFim = "${hora.toInt().plus(1)}:$minuto"

        val novaDataHorario = hashMapOf(
            "profissional" to auth.currentUser?.email.toString(),
            "dia" to calendar.get(Calendar.DAY_OF_MONTH).toString(),
            "mes" to calendar.get(Calendar.MONTH).plus(1).toString(),
            "ano" to calendar.get(Calendar.YEAR).toString(),
            "horario_inicio" to horarioInicio,
            "horario_fim" to horarioFim,
            "compareceu" to false
        )



        db.collection("horario_profissional")
            .add(novaDataHorario)
            .addOnSuccessListener {
                Toast.makeText(activity, "Horario cadastrado com sucesso", Toast.LENGTH_SHORT).show()
                binding.btnCadastrarHora?.isClickable = true
                limparCampos()
            }
            .addOnFailureListener {
                Toast.makeText(activity, "Erro: ${it.message}", Toast.LENGTH_SHORT).show()
            }

    }

    private fun limparCampos(){
        binding.edtxHora.setText("");
        binding.edtxMinuto.setText("")
    }

}