package com.example.sistema_relogio_ponto_projeto_integrador_3.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.sistema_relogio_ponto_projeto_integrador_3.R
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentLoginBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class LoginFragment : Fragment() {
    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!
    private lateinit var auth : FirebaseAuth
    private lateinit var db : FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        auth = Firebase.auth
        db = Firebase.firestore
        irPraMenuPrincipal()
        inicializarBotoesNavegacao()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null;
    }

    private fun irPraMenuPrincipal(){
        binding.btnAccess.setOnClickListener{
            val email = binding.edtEmail.text.toString().trim()
            val senha = binding.edtSenha.text.toString().trim()

            if(validarEmailSenha(email, senha)){
                verificarLoginUsuario(email,senha)
            }
        }
    }

    private fun inicializarBotoesNavegacao(){
        binding.btnRegistrar.setOnClickListener{
            findNavController().navigate(R.id.action_loginFragment_to_criarContaFragment)
        }
        binding.btnRecuperar.setOnClickListener{
            findNavController().navigate(R.id.action_loginFragment_to_recuperarSenhaFragment)
        }
    }

    private fun verificarLoginUsuario(email:String, senha:String){
        auth.signInWithEmailAndPassword(email, senha)
            .addOnCompleteListener{ task ->
                if(task.isSuccessful){
                    verificarUsuarioEmailExiste()
                }else{
                    Toast.makeText(requireContext(), "Erro: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun validarEmailSenha(email:String, senha:String) : Boolean {
        var isValido = true;

        if (email.isBlank() || senha.isBlank()) {
            Toast.makeText(
                requireContext(), "Os campos de email/senha devem estar preenchidos",
                Toast.LENGTH_SHORT
            ).show()
            isValido = false
        }else if(!email.contains("@")){
            Toast.makeText(
                requireContext(), "Preencha um email valido",
                Toast.LENGTH_SHORT
            ).show()
            isValido = false
        }
        return isValido
    }

    private fun verificarUsuarioEmailExiste(){
        db.collection("email_usuario")
            .whereEqualTo("usuario", auth.currentUser?.email.toString())
            .get()
            .addOnSuccessListener { documents ->
                if(documents.isEmpty){
                    findNavController().navigate(R.id.action_global_cadastroEmailNomeUsuarioFragment)
                }else{
                    Toast.makeText(requireContext(), "Sucesso: login realizado com sucesso", Toast.LENGTH_SHORT).show()
                    findNavController().navigate(R.id.action_global_menuPrincipalFragment)
                }
            }
            .addOnFailureListener{
                Toast.makeText(activity, "Erro: ${it.message}", Toast.LENGTH_SHORT).show()
                findNavController().popBackStack()
            }
    }

}