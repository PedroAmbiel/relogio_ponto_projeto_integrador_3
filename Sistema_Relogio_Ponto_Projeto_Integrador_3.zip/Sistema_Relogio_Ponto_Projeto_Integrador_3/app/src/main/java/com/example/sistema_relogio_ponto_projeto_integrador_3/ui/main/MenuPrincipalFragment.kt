package com.example.sistema_relogio_ponto_projeto_integrador_3.ui.main

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.sistema_relogio_ponto_projeto_integrador_3.R
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentMenuPrincipalBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import android.view.animation.AlphaAnimation
import com.google.common.base.Stopwatch
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.util.Timer
import java.util.TimerTask
import java.util.concurrent.TimeUnit
import kotlin.concurrent.timerTask


class MenuPrincipalFragment : Fragment() {

    private var _binding: FragmentMenuPrincipalBinding? = null
    private val binding get() = _binding!!
    private lateinit var auth : FirebaseAuth
    private lateinit var db : FirebaseFirestore


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentMenuPrincipalBinding.inflate(inflater, container, false)
        return _binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        auth = Firebase.auth
        db = Firebase.firestore
        iniciarFragment()

        //Handler(Looper.getMainLooper()).postDelayed(this::adicionaUsuarioAoFragment, 3000)
    }

    private fun iniciarFragment(){
        scheduleWithCoroutine()
        finalizarSessao()
        inicializarBotoes()
    }

    private fun inicializarBotoes(){
        binding.btnCadastroHoras.setOnClickListener{
            findNavController().navigate(R.id.action_menuPrincipalFragment_to_cadastroDeHorasFragment)
        }


        binding.btnMarcarPonto.setOnClickListener {
            findNavController().navigate(R.id.action_menuPrincipalFragment_to_marcarPontoFragment)
        }

        binding.btnPontosMarcados.setOnClickListener {
            findNavController().navigate(R.id.action_menuPrincipalFragment_to_relatorioHorasTrabalhadasFragment)
        }

    }

    private fun finalizarSessao(){
        binding.btnExitApp.setOnClickListener{
            auth.signOut()
            findNavController().navigate(R.id.action_menuPrincipalFragment_to_auth_navigation)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun scheduleWithCoroutine() = runBlocking {
        val stopWatch = Stopwatch.createStarted()
        launch {
            delay(500L)
            stopWatch.stop()
        }
        buscarNomeUsuario()
    }

    private fun buscarNomeUsuario(){
        val emailUsuario = db.collection("email_usuario")
        val query = emailUsuario.whereEqualTo("usuario", auth.currentUser?.email.toString())

        val nomeUsuario : String? = null

        query.get()
            .addOnSuccessListener {documents ->
               /* if(documents.isEmpty){
                    "Bem vindo!".also { binding.txtMainFragment.text = it }
                    Toast.makeText(activity, auth.currentUser.toString(), Toast.LENGTH_SHORT).show()
                }else{*/
                    for (documento in documents) {
                        "Bem vindo, ${documento.get("nome").toString()}".also { binding.txtMainFragment.text = it }
                        break
                    //}
                }
            }
            .addOnFailureListener {
                "Bem vindo!".also { binding.txtMainFragment.text = it }
            }


    }
}