package com.example.sistema_relogio_ponto_projeto_integrador_3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.TelaLoginBinding
import com.example.sistema_relogio_ponto_projeto_integrador_3.ui.MenuPrincipalFragment

class TelaLogin : AppCompatActivity() {
    private lateinit var binding : TelaLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = TelaLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnShowPassword.setOnClickListener{
            mudarInputTypeSenha()
        }

        binding.btnAccess.setOnClickListener{
            iniciarMenuPrincipal()
        }

    }

    private fun mudarInputTypeSenha(){
       if (binding.inputPassword.inputType == InputType.TYPE_CLASS_TEXT)
           binding.inputPassword.inputType = InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_CLASS_TEXT
       else
           binding.inputPassword.inputType = InputType.TYPE_CLASS_TEXT
    }

    private fun autenticarUsuario(){//TODO quando fizer integração com firebase, criar autenticação de usuário

    }

    private fun iniciarMenuPrincipal(){
        val novaTela = Intent(this, TelaPrincipalAplicativo::class.java) //Cria um Intent com a tela atual como contexto e a classe da tela destino
        novaTela.apply {
            putExtra("nomeUsuario", binding.inputUser.text.toString())
        }///Colocar valores para serem passado pelo intent

        startActivity(novaTela)
        this.finish()//Destoi a Activity de Login para não ocupar espaço
    }
}