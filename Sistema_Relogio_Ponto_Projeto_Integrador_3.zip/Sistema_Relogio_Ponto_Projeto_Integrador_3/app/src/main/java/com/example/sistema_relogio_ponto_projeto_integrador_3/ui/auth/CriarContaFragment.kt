package com.example.sistema_relogio_ponto_projeto_integrador_3.ui.auth

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.addCallback
import androidx.core.view.isVisible
import androidx.navigation.fragment.findNavController
import com.example.sistema_relogio_ponto_projeto_integrador_3.R
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentCriarContaBinding
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentLoginBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.sql.Date

class CriarContaFragment : Fragment() {
    private var _binding: FragmentCriarContaBinding? = null
    private val binding get() = _binding!!
    private lateinit var auth: FirebaseAuth
    //private lateinit var db : FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentCriarContaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null;
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        auth = Firebase.auth
        //db = Firebase.firestore
        inicializarBotoes()
        requireActivity().onBackPressedDispatcher.addCallback {
            findNavController().popBackStack()
        }
    }

    private fun inicializarBotoes(){
        binding.toolbar.setOnClickListener{
            findNavController().popBackStack()
        }

        binding.btnCriarConta.setOnClickListener {
            val email = binding.edtEmail.text.toString().trim()
            val senha = binding.edtSenha.text.toString().trim()

            if(validarEmailSenha(email, senha)){
                binding.progressBar.isVisible = true
                criarContaFirebase(email, senha)
            }
        }
    }

    private fun criarContaFirebase(email: String, senha:String){
        auth.createUserWithEmailAndPassword(email,senha)
            .addOnCompleteListener{ task ->
                if(task.isSuccessful){
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(), "Conta criada com sucesso",
                        Toast.LENGTH_SHORT).show()
                    findNavController().navigate(R.id.action_global_cadastroEmailNomeUsuarioFragment)
                }else{
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(), "Erro: ${task.exception?.message}",
                        Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun validarEmailSenha(email:String, senha:String) : Boolean {
        var isValido = true;

        if (email.isBlank() || senha.isBlank()) {
            Toast.makeText(
                requireContext(), "Os campos de email/senha devem estar preenchidos",
                Toast.LENGTH_SHORT
            ).show()
            isValido = false
        }else if(!email.contains("@")){
            Toast.makeText(
                requireContext(), "Preencha um email valido",
                Toast.LENGTH_SHORT
            ).show()
            isValido = false
        }else if(senha.length < 6){
            Toast.makeText(
                requireContext(), "A senha deve conter no mínimo 6 caracteres",
                Toast.LENGTH_SHORT
            ).show()
            isValido = false
        }
        return isValido
    }

    /*private fun adicionarContaNomeUsuario(){
        val novoUsuarioEmail = hashMapOf(
            "usuario" to auth.currentUser.toString(),
            "nome" to "",
            "sobrenome" to ""
        )


        db.collection("email_usuario")
            .add(novoUsuarioEmail)
    }*/

}