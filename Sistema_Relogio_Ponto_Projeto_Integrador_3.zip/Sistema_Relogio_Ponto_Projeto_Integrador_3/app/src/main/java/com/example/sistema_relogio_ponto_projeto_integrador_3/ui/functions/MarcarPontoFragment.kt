package com.example.sistema_relogio_ponto_projeto_integrador_3.ui.functions


import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListAdapter
import android.widget.Toast
import androidx.activity.addCallback
import androidx.core.app.ActivityCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.FragmentMarcarPontoBinding
import com.example.sistema_relogio_ponto_projeto_integrador_3.listAdapter.ListAgendaProfessorAdapter
import com.example.sistema_relogio_ponto_projeto_integrador_3.models.AgendaProfessor
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.protobuf.DescriptorProtos.SourceCodeInfo.Location
import java.util.Calendar


class MarcarPontoFragment : Fragment() {

    private var _binding: FragmentMarcarPontoBinding? = null
    private val binding get() = _binding!!
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private lateinit var db : FirebaseFirestore
    private lateinit var auth : FirebaseAuth


    private lateinit var listAdapter : ListAdapter
    private lateinit var listData : AgendaProfessor
    var dataArrayList = ArrayList<AgendaProfessor?>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentMarcarPontoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        voltarMenuPrincipal()
        auth = Firebase.auth
        db = Firebase.firestore
        requireActivity().onBackPressedDispatcher.addCallback {
            findNavController().popBackStack()
        }

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(requireActivity())
        carregarHorariosPendentesDeHoje()
        binding.btnMarcarPresenca.setOnClickListener {
            buscarLocalizacao()
        }
    }

    private fun buscarLocalizacao() {
        val task = fusedLocationProviderClient.lastLocation

        if (ActivityCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.ACCESS_FINE_LOCATION
            )
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            )
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                101
            )
            return
        }
        task.addOnSuccessListener {
            if (it != null) {
                val dist = FloatArray(1)

                android.location.Location.distanceBetween(-22.834323, -47.049158, it.latitude, it.longitude, dist)

                if (dist[0] / 1000 > 1) {//Se estiver fora de um raio de 1KM do centro da PUC
                    Toast.makeText(activity, "Não está na área acadêmica", Toast.LENGTH_SHORT).show()
                }else{
                    validarHorarioAtividade()
                }
            }else{
                Toast.makeText(activity, "Certifique-se que a localização está ativada", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }

    private fun validarHorarioAtividade(){
        val calendar = Calendar.getInstance()
        val diaAtual = calendar.get(Calendar.DAY_OF_MONTH)
        val mesAtual = calendar.get(Calendar.MONTH).plus(1)
        val anoAtual = calendar.get(Calendar.YEAR)

        var horaAtual: String =calendar.get(Calendar.HOUR_OF_DAY).toString()
        var minutoAtual: String = calendar.get(Calendar.MINUTE).toString()

        if(horaAtual.length == 1){horaAtual = "0$horaAtual"}
        if(minutoAtual.length == 1){minutoAtual = "0$minutoAtual"}
        val horarioInicioCompleto = "$horaAtual:$minutoAtual"
        //val horarioFimCompleto = "${horaAtual.toInt().plus(1)}:$minutoAtual"
        var idDocumentoASerAtualizado = ""

        db.collection("horario_profissional")
            .whereEqualTo("dia", diaAtual.toString())
            .whereEqualTo("mes", mesAtual.toString())
            .whereEqualTo("ano", anoAtual.toString())
            .whereEqualTo("profissional", auth.currentUser?.email.toString())
            .whereEqualTo("compareceu", false)
            .get()
            .addOnSuccessListener { documents ->
                if(documents.isEmpty){
                    Toast.makeText(activity, "Nenhuma atividade marcada para $diaAtual/$mesAtual - $horaAtual:$minutoAtual", Toast.LENGTH_SHORT).show()
                }
                for (documento in documents){
                    if(horarioInicioCompleto >= documento.get("horario_inicio").toString() && horarioInicioCompleto < documento.get("horario_fim").toString()){
                        //Toast.makeText(activity, "TEste aaaaaaaaaaaaaaaaaaaaaaaa", Toast.LENGTH_SHORT).show()
                        idDocumentoASerAtualizado = documento.id
                        break
                    }
                }
                if (idDocumentoASerAtualizado.isNotBlank()) {
                    atualizarDocumentoParaCompareceu(idDocumentoASerAtualizado)
                }else{
                    Toast.makeText(activity, "Nenhuma atividade marcada para $diaAtual/$mesAtual - $horaAtual:$minutoAtual", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener {
                Toast.makeText(activity, "Não foi possível verificar se existe ponto em aberto", Toast.LENGTH_SHORT).show()
            }
    }

    private fun atualizarDocumentoParaCompareceu(id : String){
        db.collection("horario_profissional").document(id)
            .update("compareceu", true)
            .addOnSuccessListener {
                Toast.makeText(activity, "Presença marcada com sucesso!", Toast.LENGTH_SHORT).show()
                carregarHorariosPendentesDeHoje()//Recarrega a lista para atualizar o compareceu
            }
            .addOnFailureListener { Toast.makeText(activity, "Erro: ${it.message}", Toast.LENGTH_SHORT).show() }

    }

    private fun carregarHorariosPendentesDeHoje(){
        val calendar = Calendar.getInstance()
        val diaAtual = calendar.get(Calendar.DAY_OF_MONTH)
        val mesAtual = calendar.get(Calendar.MONTH).plus(1)
        val anoAtual = calendar.get(Calendar.YEAR)

        //val calendar = Calendar.getInstance()
        val listaDePontos = mutableListOf<AgendaProfessor>()



        db.collection("horario_profissional")
            .whereEqualTo("dia", diaAtual.toString())
            .whereEqualTo("mes", mesAtual.toString())
            .whereEqualTo("ano", anoAtual.toString())
            .whereEqualTo("profissional", auth.currentUser?.email.toString())
            .get()
            .addOnSuccessListener {documents ->
                if(documents.isEmpty){
                binding.txtSemHorario.isVisible=true
                //Toast.makeText(activity, "Vazio", Toast.LENGTH_SHORT).show()
                }else{
                    for(documento in documents){
                        val agenda = AgendaProfessor(
                            ano = documento.get("ano").toString(),
                            mes = documento.get("mes").toString(),
                            dia = documento.get("dia").toString(),
                            horario_inicio = documento.get("horario_inicio").toString(),
                            horario_fim = documento.get("horario_fim").toString(),
                            profissional = documento.get("profissional").toString(),
                            compareceu = documento.get("compareceu").toString().toBoolean())
                        listaDePontos.add(agenda)
                    }



                    criarListaHorario(listaDePontos)
                }


            }


    }

    private fun criarListaHorario(dadosBanco : List<AgendaProfessor>){

        for (documentos in dadosBanco){
            listData = documentos
            dataArrayList.add(listData)
        }
        dataArrayList.sortByDescending { it?.horario_inicio }
        listAdapter = ListAgendaProfessorAdapter(requireContext(), dataArrayList)
        binding.listAgendaProfissional.adapter = listAdapter
        binding.listAgendaProfissional.isClickable = false


    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun voltarMenuPrincipal(){
        binding.toolbar.setOnClickListener {
            findNavController().popBackStack()
        }
    }

}