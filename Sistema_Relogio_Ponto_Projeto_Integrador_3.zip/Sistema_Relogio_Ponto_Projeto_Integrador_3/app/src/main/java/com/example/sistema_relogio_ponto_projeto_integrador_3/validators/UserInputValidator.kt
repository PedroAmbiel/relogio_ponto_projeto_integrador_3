package com.example.sistema_relogio_ponto_projeto_integrador_3.validators

import android.content.Context
import android.widget.Toast

fun validarEmailSenha(email:String, senha:String, context : Context) : Boolean {
    var isValido = true;

    if (email.isBlank() || senha.isBlank()) {
        Toast.makeText(
            context, "Os campos de email/senha devem estar preenchidos",
            Toast.LENGTH_SHORT
        ).show()
        isValido = false
    }else if(!email.contains("@")){
        Toast.makeText(
            context, "Preencha um email valido",
            Toast.LENGTH_SHORT
        ).show()
        isValido = false
    }else if(senha.length < 6){
        Toast.makeText(
            context, "A senha deve conter no mínimo 6 caracteres",
            Toast.LENGTH_SHORT
        ).show()
        isValido = false
    }
    return isValido
}

fun validarNomeSobrenome(nome: String, sobrenome: String, context: Context) : Boolean {
    if(nome.isBlank() || sobrenome.isBlank()){
        Toast.makeText(context, "Preencha os campos NOME e SOBRENOME", Toast.LENGTH_SHORT).show()
        return false
    }
    return true
}