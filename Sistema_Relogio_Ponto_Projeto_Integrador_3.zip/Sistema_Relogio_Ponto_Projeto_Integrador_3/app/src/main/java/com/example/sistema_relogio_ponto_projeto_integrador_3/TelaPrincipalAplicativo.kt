package com.example.sistema_relogio_ponto_projeto_integrador_3

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequest
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkRequest
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.ActivityTelaPrincipalAplicativoBinding
import com.example.sistema_relogio_ponto_projeto_integrador_3.workManagers.VerificarPontoWorker
import java.util.concurrent.TimeUnit


class TelaPrincipalAplicativo : AppCompatActivity() {

    private lateinit var binding: ActivityTelaPrincipalAplicativoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTelaPrincipalAplicativoBinding.inflate(layoutInflater)
        setContentView(binding.root)


        //WorkManagers
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .setRequiresCharging(false)
            .build()
        val repeatedReq = PeriodicWorkRequest.Builder(VerificarPontoWorker::class.java,15,TimeUnit.MINUTES).setConstraints(constraints).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("verificarPonto", ExistingPeriodicWorkPolicy.CANCEL_AND_REENQUEUE, repeatedReq)
    }

}