package com.example.sistema_relogio_ponto_projeto_integrador_3

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.ColorStateList
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.core.os.bundleOf
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupWithNavController
import com.example.sistema_relogio_ponto_projeto_integrador_3.databinding.ActivityTelaPrincipalAplicativoBinding
import com.example.sistema_relogio_ponto_projeto_integrador_3.ui.MenuPrincipalFragment

class TelaPrincipalAplicativo : AppCompatActivity() {

    private lateinit var binding: ActivityTelaPrincipalAplicativoBinding
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTelaPrincipalAplicativoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        iniciarToolbar()
        enviaDadosParaFragmentMenuPrincipal()
    }

    @SuppressLint("CommitTransaction")
    private fun enviaDadosParaFragmentMenuPrincipal(){
        /*val transacaoDeFragment = supportFragmentManager.beginTransaction() //Inicia edições nos fragmentos nesta activity

        val fragment = MenuPrincipalFragment.newInstance(intent.getStringExtra("nomeUsuario").toString())

        supportFragmentManager.beginTransaction()
            .replace(R.id.idFragment, fragment)
            .commit()


        transacaoDeFragment.replace(navController.graph.startDestinationId, fragment).commit()*/
        val bundle = bundleOf("data" to intent.getStringExtra("nomeUsuario").toString())

        navController.navigate(R.id.menuPrincipalFragment, bundle)

    }

    private fun iniciarToolbar(){
        val navHostFragment = supportFragmentManager
            .findFragmentById(binding.idFragment.id) as NavHostFragment
        navController=navHostFragment.navController
        appBarConfiguration = AppBarConfiguration(navController.graph)
        binding.toolbar.setupWithNavController(navController,appBarConfiguration)
    }
}